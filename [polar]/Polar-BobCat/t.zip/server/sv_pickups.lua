if Config.Notify == 'qb' then 
    QBCore = exports[Config.Core]:GetCoreObject()
elseif Config.Notify == 'esx' then
    ESX = nil
end





RegisterNetEvent('Polar-BobCat:Server:SetupPickup1', function()
    BobCatprop6()
    BobCatprop7()
    BobCatprop8()
    BobCatprop9()
    BobCatprop10()
    BobCatprop21()
    BobCatprop22()
     BobCatprop23()
     BobCatprop24()
     BobCatprop25()
end)





local BobCatprop6 = nil
RegisterNetEvent('Polar-BobCat:Server:SetBobCatprop6', function(prop) BobCatprop6 = prop end)
RegisterNetEvent('Polar-BobCat:Server:SynapseBobCatprop6', function(prop)  local src = source local Player = QBCore.Functions.GetPlayer(src)
    hiya(BobCatprop6)
end)

local BobCatprop7 = nil
RegisterNetEvent('Polar-BobCat:Server:SetBobCatprop7', function(prop) BobCatprop7 = prop end)
RegisterNetEvent('Polar-BobCat:Server:SynapseBobCatprop7', function(prop)  local src = source local Player = QBCore.Functions.GetPlayer(src)
    hiya(BobCatprop7)
end)

local BobCatprop8 = nil
RegisterNetEvent('Polar-BobCat:Server:SetBobCatprop8', function(prop) BobCatprop8 = prop end)
RegisterNetEvent('Polar-BobCat:Server:SynapseBobCatprop8', function(prop)  local src = source local Player = QBCore.Functions.GetPlayer(src)
    hiya(BobCatprop8)
end)


local BobCatprop9 = nil
RegisterNetEvent('Polar-BobCat:Server:SetBobCatprop9', function(prop) BobCatprop9 = prop end)
RegisterNetEvent('Polar-BobCat:Server:SynapseBobCatprop9', function(prop)  local src = source local Player = QBCore.Functions.GetPlayer(src)
    hiya(BobCatprop9)
end)

local BobCatprop10 = nil
RegisterNetEvent('Polar-BobCat:Server:SetBobCatprop10', function(prop) BobCatprop10 = prop end)
RegisterNetEvent('Polar-BobCat:Server:SynapseBobCatprop10', function(prop)  local src = source local Player = QBCore.Functions.GetPlayer(src)
    hiya(BobCatprop10)
end)



local BobCatprop21 = nil
RegisterNetEvent('Polar-BobCat:Server:SetBobCatprop21', function(prop) BobCatprop21 = prop end)
RegisterNetEvent('Polar-BobCat:Server:SynapseBobCatprop21', function(prop)  local src = source local Player = QBCore.Functions.GetPlayer(src)
    hiya(BobCatprop21)
end)

local BobCatprop22 = nil
RegisterNetEvent('Polar-BobCat:Server:SetBobCatprop22', function(prop) BobCatprop22 = prop end)
RegisterNetEvent('Polar-BobCat:Server:SynapseBobCatprop22', function(prop)  local src = source local Player = QBCore.Functions.GetPlayer(src)
    hiya(BobCatprop22)
end)

local BobCatprop23 = nil
RegisterNetEvent('Polar-BobCat:Server:SetBobCatprop23', function(prop) BobCatprop23 = prop end)
RegisterNetEvent('Polar-BobCat:Server:SynapseBobCatprop23', function(prop)  local src = source local Player = QBCore.Functions.GetPlayer(src)
    hiya(BobCatprop23)
end)


local BobCatprop24 = nil
RegisterNetEvent('Polar-BobCat:Server:SetBobCatprop24', function(prop) BobCatprop24 = prop end)
RegisterNetEvent('Polar-BobCat:Server:SynapseBobCatprop24', function(prop)  local src = source local Player = QBCore.Functions.GetPlayer(src)
    hiya(BobCatprop24)
end)

local BobCatprop25 = nil
RegisterNetEvent('Polar-BobCat:Server:SetBobCatprop25', function(prop) BobCatprop25 = prop end)
RegisterNetEvent('Polar-BobCat:Server:SynapseBobCatprop25', function(prop)  local src = source local Player = QBCore.Functions.GetPlayer(src)
    hiya(BobCatprop25)
end)

