if Config.Notify == 'qb' then 
    QBCore = exports[Config.Core]:GetCoreObject()
elseif Config.Notify == 'esx' then
    ESX = nil
end





RegisterNetEvent('Polar-BobCat:Server:SetupGrab1', function()
    BobCatprop1()
    BobCatprop2()
    BobCatprop3()
    BobCatprop4()
    BobCatprop5()
    BobCatprop31()
    BobCatprop32()
    BobCatprop33()
    BobCatprop34()
    BobCatprop35()
    -- BobCatprop36()
   -- BobCatprop37)
  --  BobCatprop38()
  --  BobCatprop39()
   -- BobCatprop40()
end)

local BobCatprop1 = nil
RegisterNetEvent('Polar-BobCat:Server:SetBobCatprop1', function(prop) BobCatprop1 = prop end)
RegisterNetEvent('Polar-BobCat:Server:SynapseBobCatprop1', function(prop)  local src = source local Player = QBCore.Functions.GetPlayer(src)
    hiya(BobCatprop1)
end)

local BobCatprop2 = nil
RegisterNetEvent('Polar-BobCat:Server:SetBobCatprop2', function(prop) BobCatprop2 = prop end)
RegisterNetEvent('Polar-BobCat:Server:SynapseBobCatprop2', function(prop)  local src = source local Player = QBCore.Functions.GetPlayer(src)
    hiya(BobCatprop2)
end)

local BobCatprop3 = nil
RegisterNetEvent('Polar-BobCat:Server:SetBobCatprop3', function(prop) BobCatprop3 = prop end)
RegisterNetEvent('Polar-BobCat:Server:SynapseBobCatprop3', function(prop)  local src = source local Player = QBCore.Functions.GetPlayer(src)
    hiya(BobCatprop3)
end)

local BobCatprop4 = nil
RegisterNetEvent('Polar-BobCat:Server:SetBobCatprop4', function(prop) BobCatprop4 = prop end)
RegisterNetEvent('Polar-BobCat:Server:SynapseBobCatprop4', function(prop)  local src = source local Player = QBCore.Functions.GetPlayer(src)
    hiya(BobCatprop4)
end)

local BobCatprop5 = nil
RegisterNetEvent('Polar-BobCat:Server:SetBobCatprop5', function(prop) BobCatprop5 = prop end)
RegisterNetEvent('Polar-BobCat:Server:SynapseBobCatprop5', function(prop)  local src = source local Player = QBCore.Functions.GetPlayer(src)
    hiya(BobCatprop5)
end)


    
local BobCatprop31 = nil
RegisterNetEvent('Polar-BobCat:Server:SetBobCatprop31', function(prop) BobCatprop31 = prop end)
RegisterNetEvent('Polar-BobCat:Server:SynapseBobCatprop31', function(prop)  local src = source local Player = QBCore.Functions.GetPlayer(src)
    hiya(BobCatprop31)
end)

local BobCatprop32 = nil
RegisterNetEvent('Polar-BobCat:Server:SetBobCatprop32', function(prop) BobCatprop32 = prop end)
RegisterNetEvent('Polar-BobCat:Server:SynapseBobCatprop32', function(prop)  local src = source local Player = QBCore.Functions.GetPlayer(src)
    hiya(BobCatprop32)
end)

local BobCatprop33 = nil
RegisterNetEvent('Polar-BobCat:Server:SetBobCatprop33', function(prop) BobCatprop33 = prop end)
RegisterNetEvent('Polar-BobCat:Server:SynapseBobCatprop33', function(prop)  local src = source local Player = QBCore.Functions.GetPlayer(src)
    hiya(BobCatprop33)
end)

local BobCatprop34 = nil
RegisterNetEvent('Polar-BobCat:Server:SetBobCatprop34', function(prop) BobCatprop34 = prop end)
RegisterNetEvent('Polar-BobCat:Server:SynapseBobCatprop34', function(prop)  local src = source local Player = QBCore.Functions.GetPlayer(src)
    hiya(BobCatprop34)
end)

local BobCatprop35 = nil
RegisterNetEvent('Polar-BobCat:Server:SetBobCatprop35', function(prop) BobCatprop35 = prop end)
RegisterNetEvent('Polar-BobCat:Server:SynapseBobCatprop35', function(prop)  local src = source local Player = QBCore.Functions.GetPlayer(src)
    hiya(BobCatprop35)
end)


local BobCatprop36 = nil
RegisterNetEvent('Polar-BobCat:Server:SetBobCatprop36', function(prop) BobCatprop36 = prop end)
RegisterNetEvent('Polar-BobCat:Server:SynapseBobCatprop36', function(prop)  local src = source local Player = QBCore.Functions.GetPlayer(src)
    hiya(BobCatprop36)
end)

local BobCatprop37 = nil
RegisterNetEvent('Polar-BobCat:Server:SetBobCatprop37', function(prop) BobCatprop37 = prop end)
RegisterNetEvent('Polar-BobCat:Server:SynapseBobCatprop37', function(prop)  local src = source local Player = QBCore.Functions.GetPlayer(src)
    hiya(BobCatprop37)
end)

local BobCatprop38 = nil
RegisterNetEvent('Polar-BobCat:Server:SetBobCatprop38', function(prop) BobCatprop38 = prop end)
RegisterNetEvent('Polar-BobCat:Server:SynapseBobCatprop38', function(prop)  local src = source local Player = QBCore.Functions.GetPlayer(src)
    hiya(BobCatprop38)
end)

local BobCatprop39 = nil
RegisterNetEvent('Polar-BobCat:Server:SetBobCatprop39', function(prop) BobCatprop39 = prop end)
RegisterNetEvent('Polar-BobCat:Server:SynapseBobCatprop39', function(prop)  local src = source local Player = QBCore.Functions.GetPlayer(src)
    hiya(BobCatprop39)
end)

local BobCatprop40 = nil
RegisterNetEvent('Polar-BobCat:Server:SetBobCatprop40', function(prop) BobCatprop40 = prop end)
RegisterNetEvent('Polar-BobCat:Server:SynapseBobCatprop40', function(prop)  local src = source local Player = QBCore.Functions.GetPlayer(src)
    hiya(BobCatprop40)
end)

