if Config.Notify == 'qb' then 
    QBCore = exports[Config.Core]:GetCoreObject()
elseif Config.Notify == 'esx' then
    ESX = nil
end




RegisterNetEvent('Polar-BobCat:Server:SetupTrolly1', function()
    BobCatprop16()
    BobCatprop17()
    BobCatprop18()
    BobCatprop19()
  --  BobCatprop20()
  -- BobCatprop26()
  --  BobCatprop27()
   -- BobCatprop28()
   -- BobCatprop29()
  --  BobCatprop30()
end)





local BobCatprop16 = nil
RegisterNetEvent('Polar-BobCat:Server:SetBobCatprop16', function(prop) BobCatprop16 = prop end)
RegisterNetEvent('Polar-BobCat:Server:SynapseBobCatprop16', function(prop)  local src = source local Player = QBCore.Functions.GetPlayer(src)
    trolly(BobCatprop16)
end)

local BobCatprop17 = nil
RegisterNetEvent('Polar-BobCat:Server:SetBobCatprop17', function(prop) BobCatprop17 = prop end)
RegisterNetEvent('Polar-BobCat:Server:SynapseBobCatprop17', function(prop)  local src = source local Player = QBCore.Functions.GetPlayer(src)
    trolly(BobCatprop17)
end)

local BobCatprop18 = nil
RegisterNetEvent('Polar-BobCat:Server:SetBobCatprop18', function(prop) BobCatprop18 = prop end)
RegisterNetEvent('Polar-BobCat:Server:SynapseBobCatprop18', function(prop)  local src = source local Player = QBCore.Functions.GetPlayer(src)
    trolly(BobCatprop18)
end)

local BobCatprop19 = nil
RegisterNetEvent('Polar-BobCat:Server:SetBobCatprop19', function(prop) BobCatprop19 = prop end)
RegisterNetEvent('Polar-BobCat:Server:SynapseBobCatprop19', function(prop)  local src = source local Player = QBCore.Functions.GetPlayer(src)
    trolly(BobCatprop19)
end)

local BobCatprop20 = nil
RegisterNetEvent('Polar-BobCat:Server:SetBobCatprop20', function(prop) BobCatprop20 = prop end)
RegisterNetEvent('Polar-BobCat:Server:SynapseBobCatprop20', function(prop)  local src = source local Player = QBCore.Functions.GetPlayer(src)
    trolly(BobCatprop20)
end)



local BobCatprop26 = nil
RegisterNetEvent('Polar-BobCat:Server:SetBobCatprop26', function(prop) BobCatprop26 = prop end)
RegisterNetEvent('Polar-BobCat:Server:SynapseBobCatprop26', function(prop)  local src = source local Player = QBCore.Functions.GetPlayer(src)
    trolly(BobCatprop26)
end)

local BobCatprop27 = nil
RegisterNetEvent('Polar-BobCat:Server:SetBobCatprop27', function(prop) BobCatprop27 = prop end)
RegisterNetEvent('Polar-BobCat:Server:SynapseBobCatprop27', function(prop)  local src = source local Player = QBCore.Functions.GetPlayer(src)
    trolly(BobCatprop27)
end)

local BobCatprop28 = nil
RegisterNetEvent('Polar-BobCat:Server:SetBobCatprop28', function(prop) BobCatprop28 = prop end)
RegisterNetEvent('Polar-BobCat:Server:SynapseBobCatprop28', function(prop)  local src = source local Player = QBCore.Functions.GetPlayer(src)
    trolly(BobCatprop28)
end)

local BobCatprop29 = nil
RegisterNetEvent('Polar-BobCat:Server:SetBobCatprop29', function(prop) BobCatprop29 = prop end)
RegisterNetEvent('Polar-BobCat:Server:SynapseBobCatprop29', function(prop)  local src = source local Player = QBCore.Functions.GetPlayer(src)
    trolly(BobCatprop29)
end)

local BobCatprop30 = nil
RegisterNetEvent('Polar-BobCat:Server:SetBobCatprop30', function(prop) BobCatprop30 = prop end)
RegisterNetEvent('Polar-BobCat:Server:SynapseBobCatprop30', function(prop)  local src = source local Player = QBCore.Functions.GetPlayer(src)
    trolly(BobCatprop30)
end)