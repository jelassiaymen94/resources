Config.Cash = {
     
    'w_at_ar_supp_02',
    'w_at_pi_supp_2',
  --  'w_me_stonehatchet',
    'w_pi_combatpistol_luxe',
    'w_me_switchblade',
    'w_sb_smg_mag1',
    'w_me_bottle',
    'w_ar_assaultrifle_mag2',
    'w_sr_sniperrifle_mag1',
    'w_pi_heavypistol_mag1',
}
Config.Gold = {
    'w_pi_heavypistol_luxe', 
    'w_me_knuckle_pc',
    'w_pi_pistol_luxe', 
    'w_sg_sawnoff_luxe',
    'w_sb_smg_luxe',
    'w_sr_sniperrifle_luxe',
    'w_ar_bullpuprifle_luxe',
    'w_ex_pipebomb',
    'w_sb_microsmg',
    'w_ex_pe',
    'w_ex_grenadefrag',
}
Config.Special = {
    'w_pi_wep1_gun',
    'vw_prop_vw_chips_pile_02a',
    'vw_prop_vw_chips_pile_01a',
    'w_lr_rpg_rocket',
    'w_lr_rpg',
    'h4_prop_h4_cash_bon_01a',
}
Config.ShelfSpecial = {
    'prop_peyote_gold_01', 
    'xs_prop_trophy_goldbag_01a',
    'vw_prop_vw_pogo_gold_01a',
    'h4_prop_h4_gold_coin_01a',
    'vw_prop_casino_art_egg_01a',
    'vw_prop_casino_art_miniature_09a',
    'vw_prop_casino_art_miniature_09b',
    'vw_prop_casino_art_miniature_09c',
    'vw_prop_casino_art_miniature_05a',
    'vw_prop_casino_art_miniature_05b',
    'vw_prop_casino_art_miniature_05c',
    'vw_prop_casino_art_car_09a',
    'vw_prop_casino_art_car_11a',
    'vw_prop_casino_art_grenade_01a',
    'vw_prop_casino_art_grenade_01b',
    'vw_prop_casino_art_grenade_01c',
    'vw_prop_casino_art_basketball_02a',
    'v_res_r_fighorse',
    'v_res_r_fighorsestnd',
    'ch_prop_ch_trophy_monkey_01a',
    'ch_prop_ch_trophy_racer_01a',
    'ch_prop_ch_trophy_strife_01a',
    'vw_prop_casino_art_skull_01b',
    'vw_prop_casino_art_skull_02b',
    'vw_prop_casino_art_figurines_01a',
    'vw_prop_casino_art_figurines_02a',
    'vw_prop_casino_art_lampf_01a',
    'vw_prop_toy_sculpture_01a'
   
}




