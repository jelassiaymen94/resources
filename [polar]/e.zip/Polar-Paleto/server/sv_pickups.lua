if Config.Notify == 'qb' then 
    QBCore = exports[Config.Core]:GetCoreObject()
elseif Config.Notify == 'esx' then
    ESX = nil
end





RegisterNetEvent('Polar-Paleto:Server:SetupPickup1', function()
    paletoprop6()
    paletoprop7()
    paletoprop8()
    paletoprop9()
    paletoprop10()
    paletoprop21()
    paletoprop22()
   --  paletoprop23()
   --  paletoprop24()
    -- paletoprop25()
end)



