if Config.Notify == 'qb' then 
    QBCore = exports[Config.Core]:GetCoreObject()
elseif Config.Notify == 'esx' then
    ESX = nil
end





RegisterNetEvent('Polar-Paleto:Server:SetupGrab1', function()
    paletoprop1()
    paletoprop2()
    paletoprop3()
    paletoprop4()
    paletoprop5()
    paletoprop31()
    paletoprop32()
    paletoprop33()
    paletoprop34()
    paletoprop35()
    -- paletoprop36()
   -- paletoprop37)
  --  paletoprop38()
  --  paletoprop39()
   -- paletoprop40()
end)
