if Config.Notify == 'qb' then 
    QBCore = exports[Config.Core]:GetCoreObject()
elseif Config.Notify == 'esx' then
    ESX = nil
end



RegisterNetEvent('Polar-Paleto:Server:SetupTrolly1', function()
    paletoprop16()
    paletoprop17()
    paletoprop18()
    paletoprop19()
  --  paletoprop20()
  -- paletoprop26()
  --  paletoprop27()
   -- paletoprop28()
   -- paletoprop29()
  --  paletoprop30()
end)


