if Config.Notify == 'qb' then 
    QBCore = exports[Config.Core]:GetCoreObject()
elseif Config.Notify == 'esx' then
    ESX = nil
end

RegisterNetEvent('Polar-Paleto:Server:SetupPile1', function()
    paletoprop11()
    paletoprop12()
   -- paletoprop13()
   -- paletoprop14()
   -- paletoprop15()
end)


local props = {}

RegisterNetEvent('Polar-Paleto:Server:SetPaletoProp', function(door, prop) props[door] = prop end)
RegisterNetEvent('Polar-Paleto:Server:Synapse', function(door, prop)  local src = source local Player = QBCore.Functions.GetPlayer(src)
    print(door)
    print(prop)
    hiya(props[door])
end)


