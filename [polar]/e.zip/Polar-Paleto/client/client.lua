if Config.Notify == 'qb' then 
    QBCore = exports[Config.Core]:GetCoreObject()
elseif Config.Notify == 'esx' then
    ESX = nil
end
local oxt = Config.OxTarget -- ox target
local oxdoorname = nil
local oxd = Config.OxDoorlock

local ped = PlayerPedId()
local animDict = nil local model = nil local prop = nil local var = nil local drillpos = nil local drillrot = nil local door = nil local pp = nil local coords = nil local rot = nil local position = nil local item = nil local CurrentCops = 0
local amount = nil

local doors = {}
local trollys = {}
local targets = {}

local specialgrab = 'paletograb'
local vaultdoorname = Config.VaultDoorDoor
local vaultanimloc = Config.VaultDoorThirdEye
local fingerprintdoor = ''
-- vault stuff
local vaultid = 1
local open = 37.75
local closed = -125.74
local vaultloc = vector3(-1307.85, -816.5, 17.82)

local hi = Config.Debug


local trollytable = {
    'paletoprop17',
    'paletoprop18',
    'paletoprop19',
    'paletoprop20',
    'paletoprop26',
    'paletoprop27',
    'paletoprop28',
    'paletoprop29',
    'paletoprop30',
}


--- THERMITE
local thermiteinfo = { time = 30, squares = 4, errors = 3}
local thermitetime = 20000 -- thermite burn time

local hackname = 'hacking' -- https://github.com/Jesper-Hustad/NoPixel-minigame
local circleexport = 'Polar-UI' -- https://github.com/Project-Sloth/ps-ui
local thermiteexport = 'Polar-UI' -- https://github.com/Project-Sloth/ps-ui
local fingerhack = 'utk_fingerprint' -- https://github.com/utkuali/Finger-Print-Hacking-Game
local memorygame = 'memory' 
local voltgame = 'ultra-voltlab' -- https://forum.cfx.re/t/release-voltlab-hacking-minigame-cayo-perico-mission/3933171

--- QBCORE MEMORY GAME ----------------
local memgame = false -- if using default qbcore memorygame then set to true
local memname = "memorygame"


----------------------
local drillreward = nil
function goodies()  local chance = math.random(1,100) if chance <= 25 then drillreward = 'band' amount = 3 elseif chance <= 50 then drillreward = 'band' amount = 2 elseif chance <=100 then drillreward = 'band' amount = 1 end end


local pcitem = 'btc' -- crypto or sum
local thermiteitem = "thermite"
local vaultitem = 'laptop_blue' -- bluelaptop
local vaultitemchance = 50
local drillitem = 'drill' 
local drillitemchance = 50
local carditem = 'keycard' -- vaultkeycard
local carditemchance = 50
local computeritem = 'hacking_device' -- hacking_device


local paletostartname = 'paletostart'
local paletodoor1name = 'paletodoor1'
local paletodoor2name = 'paletodoor2'
local paletodoor3name = 'paletodoor3'
local paletodoorcard1name = 'paletodoorcard1'
local paletodoorcard2name = 'paletodoorcard2'



AddEventHandler('onResourceStop', function(resource) if resource ~= GetCurrentResourceName() then return end  TriggerEvent('Polar-Paleto:Client:ResetProps') TriggerEvent('Polar-Paleto:Client:ResetDoors') TriggerEvent('Polar-Paleto:Client:ResetPropsKeypads') resetstuff() LocalPlayer.state:set('inv_busy', false, true) end)
AddEventHandler('onResourceStart', function(resource) if resource == GetCurrentResourceName() then Wait(100) if hi then print('Starting Targets')  end starttarget() blip()  end end)
RegisterNetEvent('QBCore:Client:OnPlayerLoaded', function() Wait(100) if hi then print('Player Loaded Targets Starting') end starttarget() blip()  end)
RegisterNetEvent('police:SetCopCount', function(amount) CurrentCops = amount end)
RegisterNetEvent("Polar-Paleto:Client:ThermitePtfx", function(coords) if not HasNamedPtfxAssetLoaded("scr_ornate_heist") then  RequestNamedPtfxAsset("scr_ornate_heist") end while not HasNamedPtfxAssetLoaded("scr_ornate_heist") do Wait(0) end SetPtfxAssetNextCall("scr_ornate_heist") local effect = StartParticleFxLoopedAtCoord("scr_heist_ornate_thermal_burn", coords, 0.0, 0.0, 0.0, 1.0, false, false, false, false)  Wait(thermitetime) StopParticleFxLooped(effect, 0) end)

local callback = Config.TrigCallBack -- QBCore.Functions.TriggerCallback ESX.TriggerServerCallback

RegisterNetEvent('Polar-Paleto:client:start', function()  pp = vector4(-109.43, 6483.32, 31.47, 224.11) door = paletostartname coords = vector3(-109.46, 6484.36, 31.27)
    if CurrentCops >= Config.RequiredCops then
    if playeritem(thermiteitem) then
    callback('Polar-Paleto:DoorCheckstart', function(result) if result then
    TriggerServerEvent('Polar-Paleto:Server:StopInteract', door)
    Wait(50)
        TriggerEvent('Polar-Paleto:client:ThermiteStart', pp, door, coords)
    else
        notify(text('cooldown'), "error")
    end end)
    else notify(text('nothermite'), "error") end
    else notify(text('nopolice'), "error") end
end)

RegisterNetEvent('Polar-Paleto:client:ThermiteStart', function(pp, door, coords)
                    LocalPlayer.state:set('inv_busy', true, true)
                    PlantThermite(pp, door)
        if hi then
                    LocalPlayer.state:set('inv_busy', false, true)
                    TriggerServerEvent('Polar-Paleto:Server:StartCooldown')
                    ThermiteEffect(door, coords) 
                    TriggerServerEvent('Polar-Paleto:Server:StartInteract', 'paletodoor1')
                    TriggerServerEvent('Polar-Paleto:Server:StartInteract', 'paletodoor2')
                    TriggerServerEvent('Polar-Paleto:Server:StartInteract', 'paletodoor3')
                    TriggerServerEvent('Polar-Paleto:Server:StartTargets')
        else
            if memgame then 
                exports[memname]:thermiteminigame(10, 3, 3, 10,
                function() -- success
                    LocalPlayer.state:set('inv_busy', false, true)
                    TriggerServerEvent('Polar-Paleto:Server:StartCooldown')
                    ThermiteEffect(door, coords) 
                    TriggerServerEvent('Polar-Paleto:Server:StartInteract', 'paletodoor1')
                    TriggerServerEvent('Polar-Paleto:Server:StartInteract', 'paletodoor2')
                    TriggerServerEvent('Polar-Paleto:Server:StartInteract', 'paletodoor3')
                    TriggerServerEvent('Polar-Paleto:Server:StartTargets')
                end,
                function() -- failure
                    TriggerServerEvent('Polar-Paleto:Server:StartInteract', door)
                    LocalPlayer.state:set('inv_busy', false, true)
                    notify(text('thermitefail'), "error") 
                end)
            else
                exports[thermiteexport]:Thermite(function(success) 
                if success then
                    LocalPlayer.state:set('inv_busy', false, true)
                    TriggerServerEvent('Polar-Paleto:Server:StartCooldown')
                    ThermiteEffect(door, coords) 
                    TriggerServerEvent('Polar-Paleto:Server:StartInteract', 'paletodoor1')
                    TriggerServerEvent('Polar-Paleto:Server:StartInteract', 'paletodoor2')
                    TriggerServerEvent('Polar-Paleto:Server:StartInteract', 'paletodoor3')
                    TriggerServerEvent('Polar-Paleto:Server:StartTargets')
                else 
                    TriggerServerEvent('Polar-Paleto:Server:StartInteract', door)
                    LocalPlayer.state:set('inv_busy', false, true)
                    notify(text('thermitefail'), "error") end
            end, thermiteinfo.time, thermiteinfo.squares, thermiteinfo.errors)
        end
    end
end)





RegisterNetEvent('Polar-Paleto:client:Thermite', function(pp, door, coords)
    if hi then PlantThermite(pp, door) ThermiteEffect(door, coords) else
        if playeritem(thermiteitem) then
    TriggerServerEvent('Polar-Paleto:Server:StopInteract', door)
    if math.random(1, 100) <= Config.FingerPrintPercent and not gloves() then TriggerServerEvent("evidence:server:CreateFingerDrop", GetEntityCoords(PlayerPedId())) end PlantThermite(pp, door)
    if memgame then 
        exports[memname]:thermiteminigame(10, 3, 3, 10,
        function() -- success
            TriggerServerEvent('Polar-Paleto:Server:TargetRemove', door) ThermiteEffect(door, coords)
           
        end,
        function() -- failure
            TriggerServerEvent('Polar-Paleto:Server:StartInteract', door) 
            notify(text('thermitefail'), "error") 
        end)
    else
    exports[thermiteexport]:Thermite(function(success)
    if success then TriggerServerEvent('Polar-Paleto:Server:TargetRemove', door) ThermiteEffect(door, coords)
    
    else TriggerServerEvent('Polar-Paleto:Server:StartInteract', door) 
        notify(text('thermitefail'), "error") end
    end, thermiteinfo.time, thermiteinfo.squares, thermiteinfo.errors) -- Time, Gridsize (5, 6, 7, 8, 9, 10), IncorrectBlocks
    end
    else notify(text('nothermite'), "error") end
    end
end)
function ThermiteEffect(door, coords)
    if door == 'paletostart' then CallPolice() end
    RequestAnimDict("anim@heists@ornate_bank@thermal_charge") while not HasAnimDictLoaded("anim@heists@ornate_bank@thermal_charge") do Wait(50) end Wait(1500)
    TriggerServerEvent("Polar-Paleto:Server:ThermitePtfx", vec3(coords.x, coords.y, coords.z+0.2)) Wait(500) TaskPlayAnim(PlayerPedId(), "anim@heists@ornate_bank@thermal_charge", "cover_eyes_intro", 8.0, 8.0, 1000, 36, 1, 0, 0, 0) TaskPlayAnim(PlayerPedId(), "anim@heists@ornate_bank@thermal_charge", "cover_eyes_loop", 8.0, 8.0, 3000, 49, 1, 0, 0, 0) TriggerEvent('Polar-Paleto:Client:DestroyPad', door) Wait(thermitetime) ClearPedTasks(PlayerPedId())  if oxd then  TriggerServerEvent('Polar-Paleto:Server:OxDoorlock', door, false)
    else TriggerServerEvent('qb-doorlock:server:updateState', door, false, false, false, true, false, false) end
 end 
function PlantThermite(pp, door)
    SetPedComponentVariation(PlayerPedId(), 5, Config.HideBagID, 1, 1)
    TriggerServerEvent('Polar-Paleto:Server:StopInteract', door) TriggerServerEvent('Polar-Paleto:Server:RemoveItem', thermiteitem, 1) RequestAnimDict("anim@heists@ornate_bank@thermal_charge") RequestModel("hei_p_m_bag_var22_arm_s")
    RequestNamedPtfxAsset("scr_ornate_heist") while not HasAnimDictLoaded("anim@heists@ornate_bank@thermal_charge") or not HasModelLoaded("hei_p_m_bag_var22_arm_s") or not HasNamedPtfxAssetLoaded("scr_ornate_heist") do Wait(50) end
    local pos = pp SetEntityHeading(PlayerPedId(), pos.w) Wait(100) local rotx, roty, rotz = table.unpack(vector3(GetEntityRotation(PlayerPedId()))) local netscene = NetworkCreateSynchronisedScene(pos.x, pos.y, pos.z, rotx, roty, rotz, 2, false, false, 1065353216, 0, 1.3) local bag = CreateObject('hei_p_m_bag_var22_arm_s', pos.x, pos.y, pos.z,  true,  true, false)
    SetEntityCollision(bag, false, true) local x, y, z = table.unpack(GetEntityCoords(PlayerPedId())) local thermite = CreateObject('hei_prop_heist_thermite', x, y, z + 0.2,  true,  true, true) SetEntityCollision(thermite, false, true) AttachEntityToEntity(thermite, ped, GetPedBoneIndex(PlayerPedId(), 28422), 0, 0, 0, 0, 0, 200.0, true, true, false, true, 1, true) NetworkAddPedToSynchronisedScene(PlayerPedId(), netscene, "anim@heists@ornate_bank@thermal_charge", "thermal_charge", 1.5, -4.0, 1, 16, 1148846080, 0)
    NetworkAddEntityToSynchronisedScene(bag, netscene, "anim@heists@ornate_bank@thermal_charge", "bag_thermal_charge", 4.0, -8.0, 1) SetPedComponentVariation(PlayerPedId(), 5, 0, 0, 0) NetworkStartSynchronisedScene(netscene) Wait(5000) DetachEntity(thermite, 1, 1) FreezeEntityPosition(thermite, true) DeleteObject(bag)  SetPedComponentVariation(PlayerPedId(), 5, Config.BagUseID, 1, 1) NetworkStopSynchronisedScene(netscene) CreateThread(function() Wait(15000) DeleteEntity(thermite) end)
end
function loadAnimDict(dict) while not HasAnimDictLoaded(dict) do RequestAnimDict(dict) Wait(50) end end
function loadModel(model) if type(model) == 'number' then model = model else model = GetHashKey(model) end while not HasModelLoaded(model) do RequestModel(model) Wait(0) end end
function drill(drillpos, drillrot, item, door) local pedCo = GetEntityCoords(PlayerPedId()) LocalPlayer.state:set('inv_busy', true, true) local coords, pedRotation = GetEntityCoords(PlayerPedId()), GetEntityRotation(PlayerPedId()) local animDict = 'anim_heist@hs3f@ig9_vault_drill@laser_drill@' loadAnimDict(animDict) local bagModel = 'hei_p_m_bag_var22_arm_s' loadModel(bagModel) local laserDrillModel = 'hei_prop_heist_drill' loadModel(laserDrillModel) RequestAmbientAudioBank('DLC_HEIST_FLEECA_SOUNDSET', 0) RequestAmbientAudioBank('DLC_MPHEIST\\HEIST_FLEECA_DRILL', 0) RequestAmbientAudioBank('DLC_MPHEIST\\HEIST_FLEECA_DRILL_2', 0) soundId = GetSoundId() cam = CreateCam('DEFAULT_ANIMATED_CAMERA', true) SetCamActive(cam, true) RenderScriptCams(true, 0, 3000, 1, 0) bag = CreateObject(GetHashKey(bagModel), coords, 1, 0, 0) laserDrill = CreateObject(GetHashKey(laserDrillModel), coords, 1, 0, 0)
    scene1 = NetworkCreateSynchronisedScene(drillpos, drillrot, 2, true, false, 1065353216, 0, 1.3) NetworkAddPedToSynchronisedScene(PlayerPedId(), scene1, animDict, 'intro', 4.0, -4.0, 1033, 0, 1000.0, 0) NetworkAddEntityToSynchronisedScene(bag, scene1, animDict, 'bag_intro', 1.0, -1.0, 1148846080) NetworkAddEntityToSynchronisedScene(laserDrill, scene1, animDict, 'intro_drill_bit', 1.0, -1.0, 1148846080) scene2 = NetworkCreateSynchronisedScene(drillpos, drillrot, 2, true, false, 1065353216, 0, 1.3) NetworkAddPedToSynchronisedScene(PlayerPedId(), scene2, animDict, 'drill_straight_start', 4.0, -4.0, 1033, 0, 1000.0, 0) NetworkAddEntityToSynchronisedScene(bag, scene2, animDict, 'bag_drill_straight_start', 1.0, -1.0, 1148846080) NetworkAddEntityToSynchronisedScene(laserDrill, scene2, animDict, 'drill_straight_start_drill_bit', 1.0, -1.0, 1148846080) scene3 = NetworkCreateSynchronisedScene(drillpos, drillrot, 2, true, false, 1065353216, 0, 1.3) NetworkAddPedToSynchronisedScene(PlayerPedId(), scene3, animDict, 'drill_straight_end_idle', 4.0, -4.0, 1033, 0, 1000.0, 0) NetworkAddEntityToSynchronisedScene(bag, scene3, animDict, 'bag_drill_straight_end_idle', 1.0, -1.0, 1148846080) NetworkAddEntityToSynchronisedScene(laserDrill, scene3, animDict, 'drill_straight_end_idle_drill_bit', 1.0, -1.0, 1148846080) scene4 = NetworkCreateSynchronisedScene(drillpos, drillrot, 2, true, false, 1065353216, 0, 1.3)
    NetworkAddPedToSynchronisedScene(PlayerPedId(), scene4, animDict, 'drill_straight_fail', 4.0, -4.0, 1033, 0, 1000.0, 0) NetworkAddEntityToSynchronisedScene(bag, scene4, animDict, 'bag_drill_straight_fail', 1.0, -1.0, 1148846080) NetworkAddEntityToSynchronisedScene(laserDrill, scene4, animDict, 'drill_straight_fail_drill_bit', 1.0, -1.0, 1148846080) scene5 = NetworkCreateSynchronisedScene(drillpos, drillrot, 2, true, false, 1065353216, 0, 1.3) NetworkAddPedToSynchronisedScene(PlayerPedId(), scene5, animDict, 'drill_straight_end', 4.0, -4.0, 1033, 0, 1000.0, 0) NetworkAddEntityToSynchronisedScene(bag, scene5, animDict, 'bag_drill_straight_end', 1.0, -1.0, 1148846080) NetworkAddEntityToSynchronisedScene(laserDrill, scene5, animDict, 'drill_straight_end_drill_bit', 1.0, -1.0, 1148846080) scene6 = NetworkCreateSynchronisedScene(drillpos, drillrot, 2, true, false, 1065353216, 0, 1.3) NetworkAddPedToSynchronisedScene(PlayerPedId(), scene6, animDict, 'exit', 4.0, -4.0, 1033, 0, 1000.0, 0) NetworkAddEntityToSynchronisedScene(bag, scene6, animDict, 'bag_exit', 1.0, -1.0, 1148846080) NetworkAddEntityToSynchronisedScene(laserDrill, scene6, animDict, 'exit_drill_bit', 1.0, -1.0, 1148846080)
    NetworkStartSynchronisedScene(scene1) PlayCamAnim(cam, 'intro_cam', animDict, drillpos, drillrot, 0, 2) Wait(GetAnimDuration(animDict, 'intro') * 1000) NetworkStartSynchronisedScene(scene2) PlayCamAnim(cam, 'drill_straight_start_cam', animDict, drillpos, drillrot, 0, 2) NetworkStartSynchronisedScene(scene3) PlayCamAnim(cam, 'drill_straight_idle_cam', animDict, drillpos, drillrot, 0, 2) PlaySoundFromEntity(soundId, 'Drill', laserDrill, 'DLC_HEIST_FLEECA_SOUNDSET', 1, 0)
    TriggerEvent('Drilling:Start',function(success) if success then                             
    StopSound(soundId) NetworkStartSynchronisedScene(scene5) PlayCamAnim(cam, 'drill_straight_end_cam', animDict, drillpos, drillrot, 0, 2)
    Wait(GetAnimDuration(animDict, 'drill_straight_end') * 1000) NetworkStartSynchronisedScene(scene6) PlayCamAnim(cam, 'exit_cam', animDict, drillpos, drillrot, 0, 2) Wait(GetAnimDuration(animDict, 'exit') * 1000)
    RenderScriptCams(false, false, 0, 1, 0) DestroyCam(cam, false) ClearPedTasks(PlayerPedId()) DeleteObject(bag) DeleteObject(laserDrill) LocalPlayer.state:set('inv_busy', false, true) 
    -- success
    goodies()
    TriggerServerEvent('Polar-Paleto:Server:RemoveItems', drillreward, amount)
    SetPedComponentVariation(PlayerPedId(), 5, Config.BagUseID, 0, 1)
    local chance = math.random(1,100)
    if chance <= drillitemchance then TriggerServerEvent('Polar-Paleto:Server:RemoveItem', item, 1) end
    TriggerServerEvent('Polar-Paleto:Server:TargetRemove', door) 
    else
    StopSound(soundId) NetworkStartSynchronisedScene(scene4) PlayCamAnim(cam, 'drill_straight_fail_cam', animDict, drillpos, drillrot, 0, 2) Wait(GetAnimDuration(animDict, 'drill_straight_fail') * 1000 - 1500)
    RenderScriptCams(false, false, 0, 1, 0) DestroyCam(cam, false) ClearPedTasks(PlayerPedId())  DeleteObject(bag) DeleteObject(laserDrill) LocalPlayer.state:set('inv_busy', false, true) 
    -- fail 
    SetPedComponentVariation(PlayerPedId(), 5, Config.BagUseID, 0, 1)
    local chance = math.random(1,100) TriggerServerEvent('Polar-Paleto:Server:StartInteract', door)
    if chance <= drillitemchance then TriggerServerEvent('Polar-Paleto:Server:RemoveItem', item, 1) end
    end
    end)
end

function blip()
    if Config.UseBlip then
    local blip = AddBlipForCoord(Config.BlipLocation) SetBlipSprite (blip, Config.BlipSprite) SetBlipDisplay(blip, 6) SetBlipScale (blip, 0.6) SetBlipAsShortRange(blip, true)
    SetBlipColour(blip, Config.BlipColor) BeginTextCommandSetBlipName("STRING") AddTextComponentSubstringPlayerName(Config.BlipName) EndTextCommandSetBlipName(blip)
    else return end
end
function gloves()
    local armIndex = GetPedDrawableVariation(PlayerPedId(), 3) local model = GetEntityModel(PlayerPedId()) local retval = true if model == 'mp_m_freemode_01' then if Config.MaleGloves[armIndex] ~= nil 
    and Config.MaleGloves[armIndex] then retval = false end else if Config.FemaleGloves[armIndex] ~= nil and Config.FemaleGloves[armIndex] then retval = false end end return retval
end




RegisterNetEvent('Polar-Paleto:Client:CreateTarget', function(names, coords1, handler, labels, icons, hi)
    if oxt then
        targets[names] = exports.ox_target:addBoxZone({ coords = coords1, size = vec3(1, 1, 1), rotation = 1, debug = hi,
        options = {{  event = handler,  icon = icons, label = labels, id = names }, } })
    else
        targets[names] = exports['qb-target']:AddBoxZone(names,  coords1, 0.5, 0.5, { name =  names, heading = 28.69, debug = hi, minZ = coords1.z-0.5, maxZ =  coords1.z+0.5,}, 
        { options = {{ event = handler, icon = icons, label = labels, id = names }}, distance = 1 }) 
    end
    print(names .. ' is ' .. json.encode(targets[names]))
    
end)


function other()
    TriggerEvent('Polar-Paleto:Client:CreateTarget', vaultdoorname, vaultanimloc, "Polar-Paleto:Client:VaultHack", "Hack", "fas fa-bolt", true)


    local k = 0
    local p = 0
    local distance1 = 0.22
    local distance2 = 0.22
    local space1 = nil
    local space2 = nil
    local chance = math.random(1,100) 
    if chance<=10 then   space2 = k+distance1  space1 = k+distance2 
    elseif chance<=25 then   space2 = k+distance2  space1 = k+distance1 
    elseif chance<=30 then   space2 = k-distance1  space1 = k-distance2
    elseif chance<=35 then   space2 = k-distance2  space1 = k-distance1  
    elseif chance<=40 then   space2 = k  space1 = k+distance1  
    elseif chance<=45 then   space2 = k space1 = k+distance2
    elseif chance<=50 then   space2 = k+distance2 space1 = k
    elseif chance<=55 then   space2 = k+distance1 space1 = k
    elseif chance<=60 then   space2 = k  space1 = k-distance1  
    elseif chance<=65 then   space2 = k space1 = k-distance2 
    elseif chance<=70 then   space2 = k-distance2 space1 = k 
    elseif chance<=75 then   space2 = k-distance1  space1 = k
    elseif chance<=80 then   space2 = k+distance2  space1 = k-distance2 
    elseif chance<=85 then   space2 = k-distance2  space1 = k+distance2
    elseif chance<=90 then   space2 = k+distance1  space1 = k-distance1
    elseif chance<=100 then   space2 = k-distance1  space1 = k+distance1 
    end

   
        local loc = vector4(-96.21, 6460.11, 31.63-space1, 226.61)  
        local name = "paletodrill1"
       -- adddrillspot(loc, name)
        TriggerEvent('Polar-Paleto:Client:CreateTarget', name, loc, "Polar-Paleto:Client:Drill", "Drill Lockbox", "fas fa-bolt", true)

        local loc = vector4(-96.85, 6463.54, 31.63-space2, 314.59) 
        local name = "paletodrill2"
       -- adddrillspot(loc, name)
        TriggerEvent('Polar-Paleto:Client:CreateTarget', name, loc, "Polar-Paleto:Client:Drill", "Drill Lockbox", "fas fa-bolt", true)

end 

function adddrillspot(loc, name)
    
    if oxt then
        exports.ox_target:addBoxZone({ coords = vector3(loc.x, loc.y, loc.z), size = vec3(1, 1, 1), rotation = 1, debug = hi,
        options = {{  event = "Polar-Paleto:Client:Drill", door = name, head = loc.w, coords = vec3(loc.x, loc.y, loc.z), icon = "fas fa-bolt", label = "Drill Lockbox" }, } })
    else
        exports['qb-target']:AddBoxZone(name,  vector3(loc.x, loc.y, loc.z), 0.25, 0.25, { name = name, heading = loc.w, debug = hi, minZ = loc.z-1, maxZ =  loc.z+1,}, 
        { options = {{ event = "Polar-Paleto:Client:Drill", door = name, head = loc.w, coords = vec3(loc.x, loc.y, loc.z), icon = "fas fa-bolt", label = "Drill Lockbox", excludejob = 'police', item = drillitem}}, distance = 1 }) 
    end
end








function CashAppear(grabModel)
   
    local pedCoords = GetEntityCoords(PlayerPedId())
    local grabmodel = GetHashKey(grabModel)
    loadModel(grabmodel)
    local grabobj = CreateObject(grabmodel, pedCoords, true)
    FreezeEntityPosition(grabobj, true)
    SetEntityInvincible(grabobj, true)
    SetEntityNoCollisionEntity(grabobj, ped)
    SetEntityVisible(grabobj, false, false)
    AttachEntityToEntity(grabobj, ped, GetPedBoneIndex(PlayerPedId(), 60309), 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, false, false, false, false, 0, true)
    local startedGrabbing = GetGameTimer()
    CreateThread(function()
        while GetGameTimer() - startedGrabbing < 37000 do
            Wait(1)
            DisableControlAction(0, 73, true)
            if HasAnimEventFired(PlayerPedId(), GetHashKey('CASH_APPEAR')) then
                if not IsEntityVisible(grabobj) then
                    SetEntityVisible(grabobj, true, false)
                end
            end
            if HasAnimEventFired(PlayerPedId(), GetHashKey('RELEASE_CASH_DESTROY')) then
                if IsEntityVisible(grabobj) then
                    SetEntityVisible(grabobj, false, false)
                end
            end
        end
        DeleteObject(grabobj)
    end)
end

function grabloot(door, object)
    TriggerServerEvent('Polar-Paleto:Server:TargetRemove', door)
    TriggerServerEvent('Polar-Paleto:Server:StopInteract', door)
    local prop = trollys[door]
    if prop == 'ch_prop_ch_cash_trolly_01a' then grabModel = 'hei_prop_heist_cash_pile'  end
    if prop == 'ch_prop_gold_trolly_01a' then grabModel = 'ch_prop_gold_bar_01a' end
    if prop == 'ch_prop_diamond_trolly_01a' then grabModel = 'ch_prop_vault_dimaondbox_01a' end
    local prop2 = GetEntityCoords(object)
    local rot = GetEntityRotation(object)
    print(prop)
    print(door)
    SetPedComponentVariation(PlayerPedId(), 5, Config.HideBagID, 1, 1)
    LocalPlayer.state:set('inv_busy', true, true) -- Busy
    local pedCoords, pedRotation = GetEntityCoords(PlayerPedId()), vector3(0.0, 0.0, 0.0)
    local animDict = 'anim@heists@ornate_bank@grab_cash'
    loadAnimDict(animDict)
    loadModel('hei_p_m_bag_var22_arm_s')
    local bag = CreateObject(GetHashKey('hei_p_m_bag_var22_arm_s'), pedCoords, true, false, false)
    scene1 = NetworkCreateSynchronisedScene(prop2, rot, 2, true, false, 1065353216, 0, 1.3)
    NetworkAddPedToSynchronisedScene(PlayerPedId(), scene1, animDict, 'intro', 1.5, -4.0, 1, 16, 1148846080, 0)
    NetworkAddEntityToSynchronisedScene(bag, scene1, animDict, 'bag_intro', 4.0, -8.0, 1)
    scene2 =  NetworkCreateSynchronisedScene(prop2, rot, 2, true, false, 1065353216, 0, 1.3)
    NetworkAddPedToSynchronisedScene(PlayerPedId(), scene2, animDict, 'grab', 1.5, -4.0, 1, 16, 1148846080, 0)
    NetworkAddEntityToSynchronisedScene(bag, scene2, animDict, 'bag_grab', 4.0, -8.0, 1)
    NetworkAddEntityToSynchronisedScene(object, scene2, animDict, 'cart_cash_dissapear', 4.0, -8.0, 1)
    scene3 =  NetworkCreateSynchronisedScene(prop2, rot, 2, true, false, 1065353216, 0, 1.3)
    NetworkAddPedToSynchronisedScene(PlayerPedId(), scene3, animDict, 'exit', 1.5, -4.0, 1, 16, 1148846080, 0)
    NetworkAddEntityToSynchronisedScene(bag, scene3, animDict, 'bag_exit', 4.0, -8.0, 1)
    NetworkStartSynchronisedScene(scene1)
    Wait(1750)
    CashAppear(grabModel)
    NetworkStartSynchronisedScene(scene2)
    Wait(1000)
     TriggerServerEvent('Polar-Paleto:Server:Synapse', door, prop)  
    Wait(1000)
     TriggerServerEvent('Polar-Paleto:Server:Synapse', door, prop)   
    Wait(1000)
     TriggerServerEvent('Polar-Paleto:Server:Synapse', door, prop)   
    Wait(1000)
     TriggerServerEvent('Polar-Paleto:Server:Synapse', door, prop)   
    Wait(1000)
     TriggerServerEvent('Polar-Paleto:Server:Synapse', door, prop)   
    Wait(1000)
     TriggerServerEvent('Polar-Paleto:Server:Synapse', door, prop)   
    Wait(1000)
     TriggerServerEvent('Polar-Paleto:Server:Synapse', door, prop)    
    Wait(1000)
     TriggerServerEvent('Polar-Paleto:Server:Synapse', door, prop)    
    Wait(1000)
     TriggerServerEvent('Polar-Paleto:Server:Synapse', door, prop)    
    Wait(1000)
     TriggerServerEvent('Polar-Paleto:Server:Synapse', door, prop)    
    Wait(1000)
     TriggerServerEvent('Polar-Paleto:Server:Synapse', door, prop)    
    Wait(1000)
     TriggerServerEvent('Polar-Paleto:Server:Synapse', door, prop)    
    Wait(1000)
     TriggerServerEvent('Polar-Paleto:Server:Synapse', door, prop)    
    Wait(1000)
     TriggerServerEvent('Polar-Paleto:Server:Synapse', door, prop)    
    Wait(1000)
     TriggerServerEvent('Polar-Paleto:Server:Synapse', door, prop)    
    Wait(1000)
     TriggerServerEvent('Polar-Paleto:Server:Synapse', door, prop)    
    Wait(1000)
     TriggerServerEvent('Polar-Paleto:Server:Synapse', door, prop)    
    Wait(1000)
     TriggerServerEvent('Polar-Paleto:Server:Synapse', door, prop)    
    Wait(1000)
     TriggerServerEvent('Polar-Paleto:Server:Synapse', door, prop)    
    Wait(1000)
     TriggerServerEvent('Polar-Paleto:Server:Synapse', door, prop)    
    Wait(1000)
     TriggerServerEvent('Polar-Paleto:Server:Synapse', door, prop)    
    Wait(1000)
     TriggerServerEvent('Polar-Paleto:Server:Synapse', door, prop)    
    Wait(1000)
     TriggerServerEvent('Polar-Paleto:Server:Synapse', door, prop)    
    Wait(1000)
     TriggerServerEvent('Polar-Paleto:Server:Synapse', door, prop)    
    Wait(1000)
     TriggerServerEvent('Polar-Paleto:Server:Synapse', door, prop)    
    Wait(1000)
     TriggerServerEvent('Polar-Paleto:Server:Synapse', door, prop)    
    Wait(1000)
     TriggerServerEvent('Polar-Paleto:Server:Synapse', door, prop)    
    Wait(1000)
     TriggerServerEvent('Polar-Paleto:Server:Synapse', door, prop)   
    Wait(1000)
     TriggerServerEvent('Polar-Paleto:Server:Synapse', door, prop)    
    Wait(1000)
     TriggerServerEvent('Polar-Paleto:Server:Synapse', door, prop)    
    Wait(1000)
     TriggerServerEvent('Polar-Paleto:Server:Synapse', door, prop)    
    Wait(1000)
     TriggerServerEvent('Polar-Paleto:Server:Synapse', door, prop)    
    Wait(1000)
     TriggerServerEvent('Polar-Paleto:Server:Synapse', door, prop)    
    NetworkStartSynchronisedScene(scene3)
    Wait(2000)
    DeleteObject(bag)
    ClearPedTasks(PlayerPedId())
    SetPedComponentVariation(PlayerPedId(), 5, Config.BagUseID, 0, 1)
    LocalPlayer.state:set('inv_busy', false, true) -- Not Busy
end





local zone = PolyZone:Create({
    vector2(-95.45, 6557.95),
    vector2(29.92, 6432.58),
    vector2(-119.70, 6274.62),
    vector2(-265.91, 6426.14)
  }, {
	debugPoly=false,
    name="zone",
    minZ = 16.0,
    maxZ = 35.0,
})
zone:onPlayerInOut(function(isPointInside)
    if isPointInside then
        if not Config.Vault then
        VaultForceClose() 
       
        end
    else
        if not Config.Vault then
            
            VaultForceClose() 
           
         end
    end
end)



function VaultForceClose()
    local p = false
    if p then
    local object = GetClosestObjectOfType(vaultloc, 20.0, vaultid, false, false, false)
    --print(object)
    local entHeading = open
    FreezeEntityPosition(object, false)
    SetEntityHeading(object, entHeading)
    FreezeEntityPosition(object, true)     
    else
        local object = GetClosestObjectOfType(vaultloc, 20.0, vaultid, false, false, false)
    --print(object)
    local entHeading = closed
    FreezeEntityPosition(object, false)
    while true do
        if not Config.Vault then
        if entHeading < open then
            SetEntityHeading(object, entHeading - 1)
            entHeading = entHeading + 01.004
        else
            FreezeEntityPosition(object, true)
          
            break
        end
        end
        Wait(10)
    end
    end
end
RegisterNetEvent('Polar-Paleto:Client:Vault', function(open)
    if Config.Paleto then  if oxd then  TriggerServerEvent('Polar-Paleto:Server:OxDoorlock', vaultdoorname, false) else TriggerServerEvent('qb-doorlock:server:updateState', vaultdoorname, false, false, false, true, false, false) end return end
    if not open then
    local object = GetClosestObjectOfType(vaultloc, 20.0, vaultid, false, false, false)
    --print(object)
    local entHeading = closed
    FreezeEntityPosition(object, false)
    while true do
        if entHeading < open then
            SetEntityHeading(object, entHeading - 1)
            entHeading = entHeading + 0.01
        else
            FreezeEntityPosition(object, true)
          
            break
        end

        Wait(10)
    end
    else
        local object = GetClosestObjectOfType(vaultloc, 20.0, vaultid, false, false, false)
        --print(object)
        local entHeading = open
        FreezeEntityPosition(object, false)
        while true do
            if entHeading > closed then
                SetEntityHeading(object, entHeading)
                entHeading = entHeading - 0.01
            else
                FreezeEntityPosition(object, true)
                TriggerServerEvent('Polar-Paleto:Server:VaultClose')
                break
            end
    
            Wait(10)
        end
    end
end)







RegisterNetEvent('Polar-Paleto:Client:AddPickupTarget', function(door, prop, var, pile) 
    if oxt then
        targets[door] = exports.ox_target:addBoxZone({ coords = vec3(var.x, var.y, var.z), size = vec3(1, 1, 1), rotation = 1, debug = hi,
        options = {{  event = "Polar-Paleto:Client:PickupTarget", type = door, piles = pile, icon = "fas fa-bolt", label = "Grab" }, } })
        if hi then print('grab id: ' .. rod .. ' propdoor: ' .. door .. ' proplabel: ' .. prop .. ' ispile: ') end
    else
        exports['qb-target']:AddBoxZone(door, vec3(var.x, var.y, var.z), 0.5, 0.5, { name = door, heading = 28.69, debug = hi, minZ = var.z  - 0.5, maxZ =  var.z + 0.5,}, 
        { options = {{ event = "Polar-Paleto:Client:PickupTarget", type = door, piles = pile, icon = "fas fa-bolt", label = "Grab", excludejob = 'police'}}, distance = 1.5 }) 
    end
end)





function Animation(door, props)
    if door == specialgrab then
       

        SetPedComponentVariation(PlayerPedId(), 5, Config.HideBagID, 1, 1)
        LocalPlayer.state:set('inv_busy', true, true) -- Busy
      
       
        local pedCo, pedRotation = GetEntityCoords(PlayerPedId()), GetEntityRotation(PlayerPedId())
        local animDict = ''
        

        if model == 'h4_prop_h4_gold_stack_01a' then
            animDict = 'anim@scripted@heist@ig1_table_grab@gold@male@'
            loadAnimDict(animDict)
        else
            animDict = 'anim@scripted@heist@ig1_table_grab@cash@male@'
            loadAnimDict(animDict)
        end
        TriggerServerEvent('Polar-Paleto:Server:TargetRemove', door)
        loadModel('hei_p_m_bag_var22_arm_s')
        local bag = CreateObject(GetHashKey('hei_p_m_bag_var22_arm_s'), pedCo, 1, 1, 0)
        TriggerServerEvent('Polar-Paleto:Server:StopInteract', door)
        local scene1 = NetworkCreateSynchronisedScene(GetEntityCoords(props), 
        GetEntityRotation(props), 2, true, false, 1065353216, 0, 1.3) 
        NetworkAddPedToSynchronisedScene(PlayerPedId(), scene1, animDict, 'enter', 4.0, -4.0, 1033, 0, 1000.0, 0) 
        NetworkAddEntityToSynchronisedScene(bag, scene1, animDict,'enter_bag', 1.0, -1.0, 1148846080)
        local scene2 = NetworkCreateSynchronisedScene(GetEntityCoords(props), 
        GetEntityRotation(props), 2, true, false, 1065353216, 0, 1.3) 
        NetworkAddPedToSynchronisedScene(PlayerPedId(), scene2, animDict, 'grab', 4.0, -4.0, 1033, 0, 1000.0, 0) 
        NetworkAddEntityToSynchronisedScene(bag, scene2, animDict, 'grab_bag', 1.0, -1.0, 1148846080) 
        if model == 'h4_prop_h4_gold_stack_01a' then 
        NetworkAddEntityToSynchronisedScene(props, scene2, animDict, 'grab_gold', 1.0, -1.0, 1148846080) 
        else 
        NetworkAddEntityToSynchronisedScene(props, scene2, animDict, 'grab_cash', 1.0, -1.0, 1148846080) 
        end
        local scene3 = NetworkCreateSynchronisedScene(GetEntityCoords(props), 
        GetEntityRotation(props), 2, true, false, 1065353216, 0, 1.3)
        NetworkAddPedToSynchronisedScene(PlayerPedId(), scene3, animDict, 'exit', 4.0, -4.0, 1033, 0, 1000.0, 0) 
        NetworkAddEntityToSynchronisedScene(bag, scene3, animDict, 'exit_bag', 1.0, -1.0, 1148846080) 
        NetworkStartSynchronisedScene(scene1)
        Wait(1000)
        NetworkStartSynchronisedScene(scene2)
        Wait(GetAnimDuration(animDict, 'grab') * 1000 - 3000)
        DeleteObject(props)
        NetworkStartSynchronisedScene(scene3)
        Wait(GetAnimDuration(animDict, 'exit') * 1000)        
        ClearPedTasks(PlayerPedId())
        DeleteObject(bag)
        SetPedComponentVariation(PlayerPedId(), 5, Config.BagUseID, 0, 1)
        LocalPlayer.state:set('inv_busy', false, true) 
        TriggerServerEvent('Polar-Paleto:Server:Synapse', door, sped)  
    else
        model = 'hei_p_m_bag_var22_arm_s' animDict = 'anim@scripted@heist@ig1_table_grab@cash@male@' 
       
            local playerCoords = GetEntityCoords(PlayerPedId())
            local propCoords = GetEntityCoords(props)
            local direction = vector3(propCoords.x - playerCoords.x, propCoords.y - playerCoords.y, propCoords.z - playerCoords.z)
            local heading = -math.atan2(direction.x, direction.y) * 180.0 / math.pi
            local pitch = math.asin(direction.z / #(direction)) * 180.0 / math.pi

        local dotProduct = Citizen.InvokeNative(0xBFE95ABAF46CD9B8, direction.x, direction.y, direction.z, 0.0, 0.0, 1.0)
        if dotProduct then else 
   
        SetEntityHeading(PlayerPedId(), heading)
        SetEntityRotation(PlayerPedId(), pitch, 0.0, heading, 2, true)
    
    
    TriggerServerEvent('Polar-Paleto:Server:TargetRemove', door)
    SetPedComponentVariation(PlayerPedId(), 5, Config.HideBagID, 1, 1)
    LocalPlayer.state:set('inv_busy', true, true) -- Busy
    TriggerServerEvent('Polar-Paleto:Server:StopInteract', door)
    loadAnimDict(animDict) loadModel(model) local bag = CreateObject(GetHashKey(model), playerCoords, 1, 1, 0)
    local scene1 = NetworkCreateSynchronisedScene(GetEntityCoords(props), GetEntityRotation(PlayerPedId()), 2, true, false, 1065353216, 0, 1.3)  NetworkAddPedToSynchronisedScene(PlayerPedId(), scene1, animDict, 'enter', 4.0, -4.0, 1033, 0, 1000.0, 0)  NetworkAddEntityToSynchronisedScene(bag, scene1, animDict,'enter_bag', 1.0, -1.0, 1148846080)
    local scene2 = NetworkCreateSynchronisedScene(GetEntityCoords(props), GetEntityRotation(PlayerPedId()), 2, true, false, 1065353216, 0, 1.3)  NetworkAddPedToSynchronisedScene(PlayerPedId(), scene2, animDict, 'grab', 4.0, -4.0, 1033, 0, 1000.0, 0) NetworkAddEntityToSynchronisedScene(bag, scene2, animDict, 'grab_bag', 1.0, -1.0, 1148846080)
    local scene3 = NetworkCreateSynchronisedScene(GetEntityCoords(props), GetEntityRotation(PlayerPedId()), 2, true, false, 1065353216, 0, 1.3)  NetworkAddPedToSynchronisedScene(PlayerPedId(), scene3, animDict, 'exit', 4.0, -4.0, 1033, 0, 1000.0, 0)  NetworkAddEntityToSynchronisedScene(bag, scene3, animDict, 'exit_bag', 1.0, -1.0, 1148846080)
    SetPedComponentVariation(PlayerPedId(), 5, Config.HideBagID, 0, 1) NetworkStartSynchronisedScene(scene1) Wait(1000)
    NetworkStartSynchronisedScene(scene2)
    FreezeEntityPosition(props, true)
    SetEntityInvincible(props, true)
    SetEntityNoCollisionEntity(props, ped)
    AttachEntityToEntity(props, ped, GetPedBoneIndex(PlayerPedId(), 58866), 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, false, false, false, true, 0, true)
    SetEntityRotation(props, 0.0, 0.0, 2, 2)
    Wait(500) SetEntityVisible(props, false, false)
    NetworkStartSynchronisedScene(scene3) Wait(1000) ClearPedTasks(PlayerPedId()) DeleteObject(bag) SetPedComponentVariation(PlayerPedId(), 5, Config.BagUseID, 0, 1)
    LocalPlayer.state:set('inv_busy', false, true)  
    TriggerServerEvent('Polar-Paleto:Server:Synapse', door, sped)  

      

        end
    end
end 
RegisterNetEvent('Polar-Paleto:Client:AddTarget', function(door, prop, var) 
    if oxt then 
        targets[door] = exports.ox_target:addBoxZone({ coords = vec3(var.x, var.y, var.z), size = vec3(1, 1, 1), rotation = 1, debug = hi,
        options = {{  event = "Polar-Paleto:Client:Target", type = door,  icon = "fas fa-bolt", label = "Grab" }, } })
        if hi then print('grab id: ' .. box .. ' propdoor: ' .. door .. ' proplabel: ' .. prop) end

    else
        exports['qb-target']:AddBoxZone(door, vec3(var.x, var.y, var.z), 0.5, 0.5, { name = door, heading = 28.69, debug = hi, minZ = var.z - 1.5, maxZ =  var.z + 1.5,}, 
        { options = {{ event = "Polar-Paleto:Client:Target", type = door,  icon = "fas fa-bolt", label = "Grab", excludejob = 'police'}}, distance = 1 }) 
    end
end)

RegisterNetEvent('Polar-Paleto:Client:HackComputer', function(data)
    if playeritem(computeritem) then
        print('hi')
    local door = data.door
    TriggerServerEvent('Polar-Paleto:Server:StopInteract', door) 
    local chance=math.random(1,100) 

    local time = 60
    TriggerEvent(voltgame, time, function(result,reason)
    if result == 0 then --failed
        if chance < 50 then  TriggerServerEvent('Polar-Paleto:Server:RemoveItem', computeritem, 1) end
        TriggerServerEvent('Polar-Paleto:Server:StartInteract', door) 
    elseif result == 1 then --success
        if chance < 50 then  TriggerServerEvent('Polar-Paleto:Server:RemoveItem', computeritem, 1) end
        Wait(2000)
        TriggerServerEvent('Polar-Paleto:Server:TargetRemove', door)
        TriggerServerEvent('Polar-Paleto:Server:RemoveItems', pcitem)
    elseif result == 2 then --time out
        if chance < 50 then  TriggerServerEvent('Polar-Paleto:Server:RemoveItem', computeritem, 1) end
        TriggerServerEvent('Polar-Paleto:Server:StartInteract', door) 
    elseif result == -1 then end
    end) 
    else notify(text('nopcitem'), "error") end
end)








RegisterNetEvent('Polar-Paleto:client:keycard', function(door, position, rot, item) TriggerServerEvent('Polar-Paleto:Server:StopInteract', door) 
    if playeritem(carditem) then
        if oxd then  TriggerServerEvent('Polar-Paleto:Server:OxDoorlock', door, false)  else TriggerServerEvent('qb-doorlock:server:updateState', door, false, false, false, true, false, false) end 
    local chance = math.random(1,100) local pos = GetEntityCoords(PlayerPedId()) local animDict = "anim@heists@keycard@" loadAnimDict(animDict) local prop = 'vw_prop_vw_key_card_01a' loadModel(prop) local prop2 =  CreateObject(prop, pos.x, pos.y, pos.z + 0.2,  true,  true, true)
    FreezeEntityPosition(PlayerPedId(), true) AttachEntityToEntity(prop2, ped, GetPedBoneIndex(PlayerPedId(), 28422), 0, 0, 0, 0, 0, 180.0, true, true, false, true, 1, true) SetEntityHeading(PlayerPedId(), position.w) SetEntityCoords(PlayerPedId(), vector3(position.x, position.y,position.z-1)) if chance <= carditemchance then TriggerServerEvent('Polar-Paleto:Server:RemoveItem', item, 1) end 
    TaskPlayAnim(PlayerPedId(), animDict, "enter", 5.0, 1.0, -1, 16, 0, 0, 0, 0) Wait(1000) TaskPlayAnim(PlayerPedId(), animDict, "idle_a", 5.0, 1.0, -1, 16, 0, 0, 0, 0) Wait(5000) TaskPlayAnim(PlayerPedId(), animDict, "exit", 5.0, 1.0, -1, 16, 0, 0, 0, 0) Wait(1000) StopAnimTask(PlayerPedId(), animDict, "exit", 16.0)  DeleteEntity(prop2) FreezeEntityPosition(PlayerPedId(), false) TriggerServerEvent('qb-doorlock:server:updateState', door, false, false, false, true, false, false)  notify(text('doorunlock'), "success", 2500)
    else  notify(text('nokeycard'), "error") end
end)


function next(door, loc)
    SetEntityCoords(ped, vec3(loc.x, loc.y, loc.z-1))
    local animDict = 'anim@heists@ornate_bank@hack'
    loadAnimDict(animDict)
    loadModel('hei_prop_hst_laptop')
    loadModel('hei_p_m_bag_var22_arm_s')
    local ped = PlayerPedId()
    local targetPosition, targetRotation = (vec3(GetEntityCoords(ped))), vec3(GetEntityRotation(ped))
    SetPedComponentVariation(ped, 5, Config.HideBagID, 1, 1)
    SetEntityHeading(ped, loc.w)
    local animPos = GetAnimInitialOffsetPosition(animDict, 'hack_enter', loc.x, loc.y, loc.z-0.445, loc.x, loc.y, loc.z, 0, 2)
    local animPos2 = GetAnimInitialOffsetPosition(animDict, 'hack_loop', loc.x, loc.y, loc.z-0.445, loc.x, loc.y, loc.z, 0, 2)
    local animPos3 = GetAnimInitialOffsetPosition(animDict, 'hack_exit', loc.x, loc.y, loc.z-0.445, loc.x, loc.y, loc.z, 0, 2)

    FreezeEntityPosition(ped, true)
    local netScene = NetworkCreateSynchronisedScene(animPos, targetRotation, 2, false, false, 1065353216, 0, 1.3)
    local bag = CreateObject(GetHashKey('hei_p_m_bag_var22_arm_s'), targetPosition, 1, 1, 0)
    local laptop = CreateObject(GetHashKey('hei_prop_hst_laptop'), targetPosition, 1, 1, 0)

    NetworkAddPedToSynchronisedScene(ped, netScene, animDict, 'hack_enter', 1.5, -4.0, 1, 16, 1148846080, 0)
    NetworkAddEntityToSynchronisedScene(bag, netScene, animDict, 'hack_enter_bag', 4.0, -8.0, 1)
    NetworkAddEntityToSynchronisedScene(laptop, netScene, animDict, 'hack_enter_laptop', 4.0, -8.0, 1)

    local netScene2 = NetworkCreateSynchronisedScene(animPos2, targetRotation, 2, false, true, 1065353216, 0, 1.3)
    NetworkAddPedToSynchronisedScene(ped, netScene2, animDict, 'hack_loop', 1.5, -4.0, 1, 16, 1148846080, 0)
    NetworkAddEntityToSynchronisedScene(bag, netScene2, animDict, 'hack_loop_bag', 4.0, -8.0, 1)
    NetworkAddEntityToSynchronisedScene(laptop, netScene2, animDict, 'hack_loop_laptop', 4.0, -8.0, 1)

    local netScene3 = NetworkCreateSynchronisedScene(animPos3, targetRotation, 2, false, false, 1065353216, 0, 1.3)
    NetworkAddPedToSynchronisedScene(ped, netScene3, animDict, 'hack_exit', 1.5, -4.0, 1, 16, 1148846080, 0)
    NetworkAddEntityToSynchronisedScene(bag, netScene3, animDict, 'hack_exit_bag', 4.0, -8.0, 1)
    NetworkAddEntityToSynchronisedScene(laptop, netScene3, animDict, 'hack_exit_laptop', 4.0, -8.0, 1)

    Wait(200)
    NetworkStartSynchronisedScene(netScene)
    Wait(6300)
    NetworkStartSynchronisedScene(netScene2)
    Wait(2000)
   -- if door == vaultdoorname then
        LocalPlayer.state:set('inv_busy', true, true) 
    exports[hackname]:OpenHackingGame(10, 5, 3, function(Success) 
        if Success then
            local chance = math.random(1,100)
            if chance <= vaultitemchance then TriggerServerEvent('Polar-Paleto:Server:RemoveItem', vaultitem, 1) end
            vaultdone()
            Wait(4000)
            NetworkStartSynchronisedScene(netScene3)
            Wait(4500)
            NetworkStopSynchronisedScene(netScene3)
            DeleteObject(bag)
            SetPedComponentVariation(ped, 5, Config.BagUseID, 0, 1)
            DeleteObject(laptop)
            FreezeEntityPosition(ped, false)
            LocalPlayer.state:set('inv_busy', false, true) 
            notify(text('vaultopen'), "success", 2500)
            TriggerServerEvent('Polar-Paleto:Server:TargetRemove', door) 
        else
            local chance = math.random(1,100)
            if chance <= vaultitemchance then TriggerServerEvent('Polar-Paleto:Server:RemoveItem', vaultitem, 1) end
            Wait(4000)
            NetworkStartSynchronisedScene(netScene3)
            Wait(4500)
            NetworkStopSynchronisedScene(netScene3)
            DeleteObject(bag)
            SetPedComponentVariation(ped, 5, Config.BagUseID, 0, 1)
            DeleteObject(laptop)
            FreezeEntityPosition(ped, false)
            LocalPlayer.state:set('inv_busy', false, true) 
            TriggerServerEvent('Polar-Paleto:Server:StartInteract', door)
        end
    end)
      --[[
        elseif door == fingerprintdoor then
     
            LocalPlayer.state:set('inv_busy', true, true) 
        TriggerEvent("".. fingerhack ..":Start", 4, 1, 1, function(outcome, reason) 
        if outcome == true then -- success
            local chance = math.random(1,100)
            if chance <= vaultitemchance then TriggerServerEvent('Polar-Paleto:Server:RemoveItem', vaultitem, 1) end
            doorlock(door, false)
            Wait(4000)
            NetworkStartSynchronisedScene(netScene3)
            Wait(4500)
            NetworkStopSynchronisedScene(netScene3)
            DeleteObject(bag)
            SetPedComponentVariation(ped, 5, Config.BagUseID, 0, 1)
            DeleteObject(laptop)
            FreezeEntityPosition(ped, false)
            LocalPlayer.state:set('inv_busy', false, true) 
            notify(text('doorunlock'), "success", 2500)
            TriggerServerEvent('Polar-Paleto:Server:TargetRemove', door) 
        elseif outcome == false then -- fail
            local chance = math.random(1,100)
            if chance <= vaultitemchance then TriggerServerEvent('Polar-Paleto:Server:RemoveItem', vaultitem, 1) end
            Wait(4000)
            NetworkStartSynchronisedScene(netScene3)
            Wait(4500)
            NetworkStopSynchronisedScene(netScene3)
            DeleteObject(bag)
            SetPedComponentVariation(ped, 5, Config.BagUseID, 0, 1)
            DeleteObject(laptop)
            FreezeEntityPosition(ped, false)
            LocalPlayer.state:set('inv_busy', false, true)
            TriggerServerEvent('Polar-Paleto:Server:StartInteract', door) 
        end end)
        end ]]
       
end
function hack(door)
    LocalPlayer.state:set('inv_busy', true, true) 
    TriggerServerEvent('Polar-Paleto:Server:StopInteract', door)
    local ped = PlayerPedId()
    local loc = nil local location = nil
    if door ==  vaultdoorname then  
        loc = Config.VaultDoorAnimation
       
    elseif door == Config.FingerPrintDoorDoor then
        loc = Config.FingerPrintDoor
       
    end
    SetEntityHeading(ped, loc.w)
    SetEntityCoords(ped, vec3(loc.x, loc.y, loc.z-1))
    if Config.Notify == 'esx' then
        next(door, loc)
    else
    QBCore.Functions.Progressbar("door", "Connecting to Door ..", math.random(5000, 7500), false, true, {
    disableMovement = true, disableCarMovement = true, disableMouse = false, disableCombat = true,
    }, { animDict = "anim@gangops@facility@servers@", anim = "hotwire", flags = 16,
    }, {}, {}, function() StopAnimTask(ped, "anim@gangops@facility@servers@", "hotwire", 1.0)
        next(door, loc)
    end, function() StopAnimTask(ped, "anim@gangops@facility@servers@", "hotwire", 1.0)
        TriggerServerEvent('Polar-Paleto:Server:StartInteract', door)
        LocalPlayer.state:set('inv_busy', false, true) 
    end)
    end
end

RegisterNetEvent('Polar-Paleto:client:DrillStart', function(drillpos, drillrot, door)
    if playeritem(drillitem) then
    SetPedComponentVariation(ped, 5, Config.HideBagID, 1, 1)
    TriggerServerEvent('Polar-Paleto:Server:StopInteract', door)
    drill(drillpos, drillrot, drillitem, door)
    else  notify(text('nodrill'), "error") end
end)

RegisterNetEvent('Polar-Paleto:Client:Drill', function(data)
    callback('Polar-Paleto:' .. data.door .. '', function(result) if result then 
    TriggerEvent('Polar-Paleto:client:DrillStart', data.coords, vector3(0.0, 0.0, data.head), data.door)
    else
        notify(text('sometingelse'), "error")
    end end)
end)

function vaultdone() TriggerServerEvent('Polar-Paleto:Server:Vault') end
RegisterNetEvent('Polar-Paleto:Client:VaultHack', function(data) 
    if playeritem(vaultitem) then
    callback('Polar-Paleto:VaultCheck', function(result) if result then 
        hack(targets[data.id])
    else
        notify(text('sometingelse'), "error")
    end end)
    else notify(text('novaultitem'), "error") end
end)



  
































function starttarget()
    ------ DOOR THERMITE
    if oxt then
        box = exports.ox_target:addBoxZone({ coords = Config.StartThirdEye, size = vec3(1, 1, 1), rotation = 1, debug = hi,
        options = {{  name = paletostartname, icon = "fas fa-fire", label = "Thermite", event = 'Polar-Paleto:client:start' }, } })
        if hi then print(' startbox = ' .. box .. ' ') end
    else
    
    exports['qb-target']:AddBoxZone(paletostartname, Config.StartThirdEye, 1, 1, { name = paletostartname, heading = 0.0, debug = hi, minZ = Config.StartThirdEye.z-1, maxZ =  Config.StartThirdEye.z+1,}, 
    { options = {{ event = "Polar-Paleto:client:start", icon = "fas fa-fire", label = "Thermite", excludejob = 'police', item = thermiteitem}}, distance = 1 }) 

    end
end

RegisterNetEvent('Polar-Paleto:Client:StartLoot', function()

    TriggerServerEvent('Polar-Paleto:Server:SetupGrab1')

    TriggerServerEvent('Polar-Paleto:Server:SetupPickup1')

    TriggerServerEvent('Polar-Paleto:Server:SetupPile1')

    TriggerServerEvent('Polar-Paleto:Server:SetupTrolly1')


end)

RegisterNetEvent('Polar-Paleto:Client:StartTargets', function()
    
    if oxt then

        box =  exports.ox_target:addBoxZone({ coords = vec3(Config.Door1Eye.x, Config.Door1Eye.y, Config.Door1Eye.z + 0.2), size = vec3(1, 1, 1), rotation = 1, debug = hi,
        options = {{  name = paletodoor1name, icon = "fas fa-fire", label = "Thermite", event = 'Polar-Paleto:Client:Door1' }, } })
        if hi then print(' ' .. paletodoor1name .. box .. '') end
        box =  exports.ox_target:addBoxZone({ coords = vec3(Config.Door2Eye.x, Config.Door2Eye.y, Config.Door2Eye.z + 0.2), size = vec3(1, 1, 1), rotation = 1, debug = hi,
        options = {{  name = paletodoor2name, icon = "fas fa-fire", label = "Thermite", event = 'Polar-Paleto:Client:Door2' }, } })
        if hi then print(' ' .. paletodoor2name .. box .. '') end
        box =  exports.ox_target:addBoxZone({ coords = vec3(Config.Door3Eye.x, Config.Door3Eye.y, Config.Door3Eye.z + 0.2), size = vec3(1, 1, 1), rotation = 1, debug = hi,
        options = {{  name = paletodoor3name, icon = "fas fa-fire", label = "Thermite", event = 'Polar-Paleto:Client:Door3' }, } })
        if hi then print(' ' .. paletodoor3name .. box .. '') end
        box =  exports.ox_target:addBoxZone({ coords = vec3(Config.doorcard1Eye.x, Config.doorcard1Eye.y, Config.doorcard1Eye.z + 0.2), size = vec3(1, 1, 1), rotation = 1, debug = hi,
        options = {{  name = paletodoorcard1name, icon = "fas fa-bolt", label = "Insert Card", event = 'Polar-Paleto:Client:doorcard1' }, } })
        if hi then print(' ' .. paletodoorcard1name .. box .. '') end
        box =  exports.ox_target:addBoxZone({ coords = vec3(Config.doorcard2Eye.x, Config.doorcard2Eye.y, Config.doorcard2Eye.z + 0.2), size = vec3(1, 1, 1), rotation = 1, debug = hi,
        options = {{  name = paletodoorcard2name, icon = "fas fa-bolt", label = "Insert Card", event = 'Polar-Paleto:Client:doorcard2' }, } })
        if hi then print(' ' .. paletodoorcard2name .. box .. '') end
        box =  exports.ox_target:addBoxZone({ coords = Config.Pc1, size = vec3(1, 1, 1), rotation = 1, debug = hi,
        options = {{  name = Config.Pc1name, icon = "fas fa-bolt", label = "Hack", door = Config.Pc1name, event = 'Polar-Paleto:Client:HackComputer' }, } })
        if hi then print(' ' .. Config.Pc1name .. box .. '') end
        box =  exports.ox_target:addBoxZone({ coords = Config.Pc2, size = vec3(1, 1, 1), rotation = 1, debug = hi,
        options = {{  name = Config.Pc2name, icon = "fas fa-bolt", label = "Hack", door = Config.Pc2name, event = 'Polar-Paleto:Client:HackComputer' }, } })
        if hi then print(' ' .. Config.Pc2name .. box .. '') end
        box =  exports.ox_target:addBoxZone({ coords = Config.Pc3, size = vec3(1, 1, 1), rotation = 1, debug = hi,
        options = {{  name = Config.Pc3name, icon = "fas fa-bolt", label = "Hack", door = Config.Pc3name, event = 'Polar-Paleto:Client:HackComputer' }, } })
        if hi then print(' ' .. Config.Pc3name .. box .. '') end
      
    else
    
   
    exports['qb-target']:AddBoxZone(paletodoor1name, vec3(Config.Door1Eye.x, Config.Door1Eye.y, Config.Door1Eye.z + 0.2), 1, 1, { name = paletodoor1name, heading = 0.0, debug = hi, minZ = Config.Door1Eye.z-1, maxZ =  Config.Door1Eye.z+1,}, 
    { options = {{ event = "Polar-Paleto:Client:Door1", icon = "fas fa-fire", label = "Thermite", excludejob = 'police'}}, distance = 1 }) 
    exports['qb-target']:AddBoxZone(paletodoor2name, vec3(Config.Door2Eye.x, Config.Door2Eye.y, Config.Door2Eye.z + 0.2), 1, 1, { name = paletodoor2name, heading = 0.0, debug = hi, minZ = Config.Door2Eye.z-1, maxZ =  Config.Door2Eye.z+1,}, 
    { options = {{ event = "Polar-Paleto:Client:Door2", icon = "fas fa-fire", label = "Thermite", excludejob = 'police'}}, distance = 1 }) 
    exports['qb-target']:AddBoxZone(paletodoor3name, vec3(Config.Door3Eye.x, Config.Door3Eye.y, Config.Door3Eye.z + 0.2), 1, 1, { name = paletodoor3name, heading = 0.0, debug = hi, minZ = Config.Door3Eye.z-1, maxZ =  Config.Door3Eye.z+1,}, 
    { options = {{ event = "Polar-Paleto:Client:Door3", icon = "fas fa-fire", label = "Thermite", excludejob = 'police'}}, distance = 1 }) 
    
    exports['qb-target']:AddBoxZone(paletodoorcard1name, vec3(Config.doorcard1Eye.x, Config.doorcard1Eye.y, Config.doorcard1Eye.z + 0.2), 1, 1, { name = paletodoorcard1name, heading = 0.0, debug = hi, minZ = Config.doorcard1Eye.z-1, maxZ =  Config.doorcard1Eye.z+1,}, 
    { options = {{ event = "Polar-Paleto:Client:doorcard1", icon = "fas fa-bolt", label = "Insert Card", excludejob = 'police'}}, distance = 1 }) 
    exports['qb-target']:AddBoxZone(paletodoorcard2name, vec3(Config.doorcard2Eye.x, Config.doorcard2Eye.y, Config.doorcard2Eye.z + 0.2), 1, 1, { name = paletodoorcard2name, heading = 0.0, debug = hi, minZ = Config.doorcard2Eye.z-1, maxZ =  Config.doorcard2Eye.z+1,}, 
    { options = {{ event = "Polar-Paleto:Client:doorcard2", icon = "fas fa-bolt", label = "Insert Card", excludejob = 'police'}}, distance = 1 }) 
   
    exports['qb-target']:AddBoxZone(Config.Pc1name, Config.Pc1, 2, 2, { name = Config.Pc1name, heading = 28.69, debug = hi, minZ = Config.Pc1-1, maxZ =  Config.Pc1+1,}, 
    { options = {{ event = "Polar-Paleto:Client:HackComputer", door = Config.Pc1name, icon = "fas fa-bolt", label = "Hack", excludejob = 'police' }}, distance = 1 }) 
    exports['qb-target']:AddBoxZone(Config.Pc2name, Config.Pc2, 2, 2, { name = Config.Pc2name, heading = 28.69, debug = hi, minZ = Config.Pc2-1, maxZ =  Config.Pc2+1,}, 
    { options = {{ event = "Polar-Paleto:Client:HackComputer", door = Config.Pc2name, icon = "fas fa-bolt", label = "Hack", excludejob = 'police'}}, distance = 1 }) 
    exports['qb-target']:AddBoxZone(Config.Pc3name, Config.Pc3, 2, 2, { name = Config.Pc3name, heading = 28.69, debug = hi, minZ = Config.Pc3-1, maxZ =  Config.Pc3+1,}, 
    { options = {{ event = "Polar-Paleto:Client:HackComputer", door = Config.Pc3name, icon = "fas fa-bolt", label = "Hack", excludejob = 'police'}}, distance = 1 }) 
    
    end

    other()

end)


--- Thermites
RegisterNetEvent('Polar-Paleto:Client:Door1', function() pp = vec4(Config.Door1Thermite.x, Config.Door1Thermite.y, Config.Door1Thermite.z + 0.2, Config.Door1Thermite.w) door = paletodoor1name coords =  Config.Door1Pfx callback('Polar-Paleto:Door1', function(result) if result then TriggerEvent('Polar-Paleto:client:Thermite', pp, door, coords) else  notify(text('sometingelse'), "error") end end) end)
RegisterNetEvent('Polar-Paleto:Client:Door2', function() pp = vec4(Config.Door2Thermite.x, Config.Door2Thermite.y, Config.Door2Thermite.z + 0.2, Config.Door2Thermite.w) door = paletodoor2name coords =  Config.Door2Pfx callback('Polar-Paleto:Door2', function(result) if result then TriggerEvent('Polar-Paleto:client:Thermite', pp, door, coords) else  notify(text('sometingelse'), "error") end end) end)
RegisterNetEvent('Polar-Paleto:Client:Door3', function() pp = vec4(Config.Door3Thermite.x, Config.Door3Thermite.y, Config.Door3Thermite.z + 0.2, Config.Door3Thermite.w) door = paletodoor3name coords =  Config.Door3Pfx callback('Polar-Paleto:Door3', function(result) if result then TriggerEvent('Polar-Paleto:client:Thermite', pp, door, coords) else  notify(text('sometingelse'), "error") end end) end)
----- CARD INSERT
RegisterNetEvent('Polar-Paleto:Client:doorcard1', function() item = carditem  rot = vector3(0.0, 0.0, 37.0) position = Config.doorcard1swipe door = paletodoorcard1name TriggerEvent('Polar-Paleto:client:keycard', door, position, rot, item) end)
RegisterNetEvent('Polar-Paleto:Client:doorcard2', function() item = carditem  rot = vector3(0.0, 0.0, 37.0) position = Config.doorcard2swipe door = paletodoorcard2name TriggerEvent('Polar-Paleto:client:keycard', door, position, rot, item) end)






























---- grabs 1-5 and 31-40


function resetstuff()
    for i = 1, 40 do
        if hi then print('setting to nil ' .. i .. ' / 40') end
        _G["paletoprop" .. i] = nil
    end
end


RegisterNetEvent('Polar-Paleto:Client:PaletoProp', function(door, prop, var) 

    loadModel(prop) 
    doors[door] =  CreateObject(prop, var.x, var.y, var.z,  true,  true, true) 
    print(doors[door])
    SetEntityHeading(doors[door], var.w) 
    TriggerServerEvent('Polar-Paleto:Server:StartInteract', door)
 
end)










RegisterNetEvent('Polar-Paleto:Client:TargetRemove', function(door) 
    if hi then print(doors[door]) end
    for _, v in ipairs(trollytable) do
        if v == door then
            
            break   
        else
            if DoesEntityExist(doors[door]) then DeleteEntity(doors[door]) end
            break
        end
    end

    if door == nil then return end
    if oxt then
        exports.ox_target:removeZone(targets[door])
       
   
    else
        exports['qb-target']:RemoveZone(door) 
    end
    
end)

RegisterNetEvent('Polar-Paleto:Client:SetTrollyProp', function(door, prop)
    trollys[door] = prop 

end)

RegisterNetEvent('Polar-Paleto:Client:Target', function(data) 
    local p = data.type 
    --print(doors[p])
    --print(p)
   -- print(GetEntityRotation(doors[p]))
   
    TriggerServerEvent('Polar-Paleto:Server:StopInteract', p)
    for _, v in ipairs(trollytable) do
        if v == p then
            grabloot(p, doors[p])  
            break   
        else
            Animation(p, doors[p], prop)  
            break
        end
    end
end)


RegisterNetEvent('Polar-Paleto:Client:ResetProps', function(d)
    if doors[d] == nil then
    else
    if DoesEntityExist(doors[d]) then DeleteEntity(doors[d]) targetname = 'paletoprop1' end
    --if DoesEntityExist(paletoprop2) then DeleteEntity(paletoprop2) targetname = 'paletoprop2' end
  --  if DoesEntityExist(paletoprop3) then DeleteEntity(paletoprop3) targetname = 'paletoprop3' end
  --  if DoesEntityExist(paletoprop4) then DeleteEntity(paletoprop4) targetname = 'paletoprop4' end
   -- if DoesEntityExist(paletoprop5) then DeleteEntity(paletoprop5) targetname = 'paletoprop5' end
    if DoesEntityExist(paletoprop6) then DeleteEntity(paletoprop6) targetname = 'paletoprop6' end
    if DoesEntityExist(paletoprop7) then DeleteEntity(paletoprop7) targetname = 'paletoprop7' end
    if DoesEntityExist(paletoprop8) then DeleteEntity(paletoprop8) targetname = 'paletoprop8' end
    if DoesEntityExist(paletoprop9) then DeleteEntity(paletoprop9) targetname = 'paletoprop9' end
    if DoesEntityExist(paletoprop10) then DeleteEntity(paletoprop10) targetname = 'paletoprop10' end
    if DoesEntityExist(paletoprop11) then DeleteEntity(paletoprop11) targetname = 'paletoprop11' end
    if DoesEntityExist(paletoprop12) then DeleteEntity(paletoprop12) targetname = 'paletoprop12' end
    if DoesEntityExist(paletoprop13) then DeleteEntity(paletoprop13) targetname = 'paletoprop13' end
    if DoesEntityExist(paletoprop14) then DeleteEntity(paletoprop14) targetname = 'paletoprop14' end
    if DoesEntityExist(paletoprop15) then DeleteEntity(paletoprop15) targetname = 'paletoprop15' end
    if DoesEntityExist(paletoprop16) then DeleteEntity(paletoprop16) targetname = 'paletoprop16' end
    if DoesEntityExist(paletoprop17) then DeleteEntity(paletoprop17) targetname = 'paletoprop17' end
    if DoesEntityExist(paletoprop18) then DeleteEntity(paletoprop18) targetname = 'paletoprop18' end
    if DoesEntityExist(paletoprop19) then DeleteEntity(paletoprop19) targetname = 'paletoprop19' end
    if DoesEntityExist(paletoprop20) then DeleteEntity(paletoprop20) targetname = 'paletoprop20' end
    if DoesEntityExist(paletoprop21) then DeleteEntity(paletoprop21) targetname = 'paletoprop21' end
    if DoesEntityExist(paletoprop22) then DeleteEntity(paletoprop22) targetname = 'paletoprop22' end
    if DoesEntityExist(paletoprop23) then DeleteEntity(paletoprop23) targetname = 'paletoprop23' end
    if DoesEntityExist(paletoprop24) then DeleteEntity(paletoprop24) targetname = 'paletoprop24' end
    if DoesEntityExist(paletoprop25) then DeleteEntity(paletoprop25) targetname = 'paletoprop25' end
    if DoesEntityExist(paletoprop26) then DeleteEntity(paletoprop26) targetname = 'paletoprop26' end
    if DoesEntityExist(paletoprop27) then DeleteEntity(paletoprop27) targetname = 'paletoprop27' end
    if DoesEntityExist(paletoprop28) then DeleteEntity(paletoprop28) targetname = 'paletoprop28' end
    if DoesEntityExist(paletoprop29) then DeleteEntity(paletoprop29) targetname = 'paletoprop29' end
    if DoesEntityExist(paletoprop30) then DeleteEntity(paletoprop30) targetname = 'paletoprop30' end
    if DoesEntityExist(paletoprop31) then DeleteEntity(paletoprop31) targetname = 'paletoprop31' end
    if DoesEntityExist(paletoprop32) then DeleteEntity(paletoprop32) targetname = 'paletoprop32' end
    if DoesEntityExist(paletoprop33) then DeleteEntity(paletoprop33) targetname = 'paletoprop33' end
    if DoesEntityExist(paletoprop34) then DeleteEntity(paletoprop34) targetname = 'paletoprop34' end
    if DoesEntityExist(paletoprop35) then DeleteEntity(paletoprop35) targetname = 'paletoprop35' end
    if DoesEntityExist(paletoprop36) then DeleteEntity(paletoprop36) targetname = 'paletoprop36' end
    if DoesEntityExist(paletoprop37) then DeleteEntity(paletoprop37) targetname = 'paletoprop37' end
    if DoesEntityExist(paletoprop38) then DeleteEntity(paletoprop38) targetname = 'paletoprop38' end
    if DoesEntityExist(paletoprop39) then DeleteEntity(paletoprop39) targetname = 'paletoprop39' end
    if DoesEntityExist(paletoprop40) then DeleteEntity(paletoprop40) targetname = 'paletoprop40' end
    if targetname == nil then return end
    if oxt then
        exports.ox_target:removeZone(targetname)
    else
        exports['qb-target']:RemoveZone(targetname)
    end
    end
end)


RegisterNetEvent('Polar-Paleto:Client:PickupTarget', function(data) 
    LocalPlayer.state:set('inv_busy', true, true) -- Busy
    animDict = 'random@domestic'
    local pile = data.piles
    local door = data.type
    local numba = data.number
    if pile then  
        TriggerServerEvent('Polar-Paleto:Server:TargetRemove', door) 
        loadAnimDict('amb@medic@standing@kneel@base')
        loadAnimDict('anim@gangops@facility@servers@bodysearch@')
        TaskPlayAnim(PlayerPedId(), 'amb@medic@standing@kneel@base', 'base', 8.0, 8.0, -1, 1, 0, false, false, false)
        TaskPlayAnim(PlayerPedId(), 'anim@gangops@facility@servers@bodysearch@', 'player_search', 8.0, 8.0, -1, 48, 0, false, false, false)
        Wait(5000)
        ClearPedTasks(PlayerPedId())

    else
        loadAnimDict(animDict) TaskPlayAnim(PlayerPedId(), animDict, 'pickup_low', 3.0, 3.0, -1, 0, 0, 0, 0, 0) 
    end
        TriggerServerEvent('Polar-Paleto:Server:Synapse', door, prop)  
        TriggerServerEvent('Polar-Paleto:Server:StopInteract', door)
        LocalPlayer.state:set('inv_busy', false, true)
        TriggerServerEvent('Polar-Paleto:Server:TargetRemove', door) 
end)



RegisterNetEvent('Polar-Paleto:Client:ResetDoors', function()
    if oxd then
        TriggerServerEvent('Polar-Paleto:Server:OxDoorlock', paletodoor1name, true)
        TriggerServerEvent('Polar-Paleto:Server:OxDoorlock', paletodoor2name, true)
        TriggerServerEvent('Polar-Paleto:Server:OxDoorlock', paletodoor3name, true)
        TriggerServerEvent('Polar-Paleto:Server:OxDoorlock', paletodoorcard1name, true)
        TriggerServerEvent('Polar-Paleto:Server:OxDoorlock', paletodoorcard2name, true)
        TriggerServerEvent('Polar-Paleto:Server:OxDoorlock', Config.VaultDoorDoor, true)
       
    else
    TriggerServerEvent('qb-doorlock:server:updateState', paletodoor1name, true, false, false, true, false, false)
    TriggerServerEvent('qb-doorlock:server:updateState', paletodoor2name, true, false, false, true, false, false)
    TriggerServerEvent('qb-doorlock:server:updateState', paletodoor3name, true, false, false, true, false, false)
    TriggerServerEvent('qb-doorlock:server:updateState', paletodoorcard1name, true, false, false, true, false, false)
    TriggerServerEvent('qb-doorlock:server:updateState', paletodoorcard2name, true, false, false, true, false, false)
    TriggerServerEvent('qb-doorlock:server:updateState', Config.VaultDoorDoor, true, false, false, true, false, false)
 --   doorlock(paletodoor1name, true)
  --  doorlock(paletodoor2name, true)
  --  doorlock(paletodoor3name, true)
  --  doorlock(paletodoorcard1name, true)
  --  doorlock(paletodoorcard2name, true)
 --   doorlock(Config.VaultDoorDoor, true)
    end
end)

function doorlock(name, what)
    print(' and the name is ' .. name .. ' john the rock ' .. what .. ' cena')
    if oxd then  TriggerServerEvent('Polar-BobCat:Server:OxDoorlock', name, what)
    else 
    TriggerServerEvent('qb-doorlock', name, what, false, false, true, false, false)
    end
end

function playeritem(item, amount)
    if Config.Notify == 'qb' then
    return exports['qb-inventory']:HasItem(item, amount)
    else
        
    end
end
  
function notify(what, color)
    if Config.Notify == 'qb' then
        QBCore.Functions.Notify(what, color)
    elseif Config.Notify == 'esx' then
        if color == 'error' then colo = 'r' elseif color == 'success' then colo = 'g' end
        ESX.ShowNotification(what, true, true, colo)
    end
end
 
  