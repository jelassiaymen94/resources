Config.Cash = {
    'prop_cash_pile_01',
    'prop_cash_pile_02',
    'prop_anim_cash_pile_01',
    'prop_anim_cash_pile_02', 
    'bkr_prop_bkr_cash_roll_01'
}
Config.Gold = {
    'ch_prop_gold_bar_01a', 
    'hei_prop_heist_gold_bar', 
    'prop_gold_bar'
}
Config.Special = {
    'ex_prop_exec_award_gold',
    'vw_prop_casino_art_bird_01a',
    'vw_prop_art_pug_02a',
    'vw_prop_casino_art_horse_01a',
    'vw_prop_casino_art_panther_01c',
    'vw_prop_miniature_yacht_01a',
    'vw_prop_miniature_yacht_01b',
    'vw_prop_miniature_yacht_01c',
    'vw_prop_vw_chips_pile_02a',
    'vw_prop_vw_chips_pile_01a',
}
Config.ShelfSpecial = {
    'prop_peyote_gold_01', 
    'xs_prop_trophy_goldbag_01a',
    'vw_prop_vw_pogo_gold_01a',
    'h4_prop_h4_gold_coin_01a',
    'vw_prop_casino_art_egg_01a',
    'vw_prop_casino_art_miniature_09a',
    'vw_prop_casino_art_miniature_09b',
    'vw_prop_casino_art_miniature_09c',
    'vw_prop_casino_art_miniature_05a',
    'vw_prop_casino_art_miniature_05b',
    'vw_prop_casino_art_miniature_05c',
    'vw_prop_casino_art_car_09a',
    'vw_prop_casino_art_car_11a',
    'vw_prop_casino_art_grenade_01a',
    'vw_prop_casino_art_grenade_01b',
    'vw_prop_casino_art_grenade_01c',
    'vw_prop_casino_art_basketball_02a',
    'v_res_r_fighorse',
    'v_res_r_fighorsestnd',
    'ch_prop_ch_trophy_monkey_01a',
    'ch_prop_ch_trophy_racer_01a',
    'ch_prop_ch_trophy_strife_01a',
    'vw_prop_casino_art_skull_01b',
    'vw_prop_casino_art_skull_02b',
    'vw_prop_casino_art_figurines_01a',
    'vw_prop_casino_art_figurines_02a',
    'vw_prop_casino_art_lampf_01a',
    'vw_prop_toy_sculpture_01a'
   
}




