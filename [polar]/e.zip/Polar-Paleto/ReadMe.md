# Description
Paleto Bank Robbery Script

-- GABZ PALETO BANK

* **EASY INSTALLATION**
* QbCore Framework

# Installation

* **Install all dependencies**


If you use qb-doorlock then just drag the paletobankdoors.lua file with the doors into your qb-doorlock>configs folder

To change loot tables find loot.lua

To edit random locations they are located in most of the sh_ files. 

To edit props they are located sh_props.lua



# Credits
Made by Balake#0463 @ Polar Development

Discord: https://discord.gg/polar

Tebex: https://polarscripts.tebex.io/


** QB-core items

["btc"]					= {["name"] = "btc",					["label"] = "Crypto Coin",		["weight"] = 5000, 		["type"] = "item", 		["image"] = "btc.png", 				 	 	     ["description"] = "Highly Valuable Coin"},

['hacking_device']			  = {['name'] = "hacking_device",					['label'] = "Illegal Device",			['weight'] = 4000,		['type'] = 'item', 		['image'] = 'hackerdevice.png',			['unique'] = true,		['useable']	= true,		['shouldClose'] = true,	   ['combinable'] = nil,   ['description'] = "A multi purpose hacking device"},

["keycard"] 					 		 	 = {["name"] = "keycard",  	    						["label"] = "Employee Key Card",	 				["weight"] = 500, 		["type"] = "item", 		["image"] = "security_card_01.png", 						["unique"] = true, 	["useable"] = true, 	["shouldClose"] = true,   	["combinable"] = nil,   	 ["description"] = "Some unlucky employee's key card.", },

["laptop_blue"] 				 = {["name"] = "laptop_blue", 			  	  	["label"] = "Blue Laptop", 				["weight"] = 10000, 		["type"] = "item", 		["image"] = "laptop_blue.png", 			["unique"] = true, 		["useable"] = true, 	["shouldClose"] = true,	   ["combinable"] = nil,   ["description"] = "A security Laptop"},

**